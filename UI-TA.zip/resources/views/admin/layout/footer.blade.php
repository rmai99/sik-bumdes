<div class="container-fluid">
    <nav class="float-left">
    </nav>
    <div class="copyright float-right">
        &copy;
        <strong>SIK BUMDES</strong>, All rights reserved
    </div>
</div>

<?php $__env->startSection('title', 'Jurnal Umum'); ?>

<?php $__env->startSection('title-page', 'Jurnal Umum'); ?>

<?php $__env->startSection('content'); ?>
    <?php
    if(isset($_GET['year']) || isset($_GET['month']) || isset($_GET['day'])){
        if (isset($_GET['year'], $_GET['month'], $_GET['day'])) {
            $year = $_GET['year'];
            $month = $_GET['month'];
            $day = $_GET['day'];
            // # code...
        }elseif(isset($_GET['year'], $_GET['month'])){
            
            $year = $_GET['year'];
            $month = $_GET['month'];
            $day = null;
        }elseif(isset($_GET['year'])){

            $year = $_GET['year'];
            $month = null;
            $day = null;
        }
    } else {
        $year = date('Y');
        $month = null;
        $day = null;
    }
    ?>

<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="header text-center mt-2">
                        <h3 class="title" style="font-weight: 400;">Jurnal Umum</h3>
                        <p class=""><strong>Periode</strong> <?php echo e($year); ?> </p>
                    </div>
                    <div class="card-body">
                        <div class="toolbar">
                            <div class="row d-flex">
                                <div class="col-md-1 pr-2">
                                    <div class="form-group">
                                        <strong class="mr-3">Tahun</strong>
                                        <select class="w-100 pl-1 padding-select groupbyYear" style="border-radius: 3px;">
                                            <option value="0" disabled="true" selected="true">Year</option>
                                            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option id="year" name="year" value="<?php echo e($y->year); ?>"
                                                <?php echo e($year == $y->year ? 'selected' : ''); ?>><?php echo e($y->year); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-1 pl-0 pr-2">
                                    <div class="form-group">
                                        <strong class="mr-3">Bulan</strong>
                                        <select class="w-100 pl-1 padding-select groupbyMonth" style="border-radius: 3px;">
                                            <option value="0" disabled="true" selected="true">Month</option>
                                            <option value="0">All</option>
                                            <option value="01" <?php echo e($month == '01' ? 'selected' : ''); ?>>Januari</option>
                                            <option value="02" <?php echo e($month == '02' ? 'selected' : ''); ?>>Februari</option>
                                            <option value="03" <?php echo e($month == '03' ? 'selected' : ''); ?>>Maret</option>
                                            <option value="04" <?php echo e($month == '04' ? 'selected' : ''); ?>>April</option>
                                            <option value="05" <?php echo e($month == '05' ? 'selected' : ''); ?>>Mei</option>
                                            <option value="06" <?php echo e($month == '06' ? 'selected' : ''); ?>>Juni</option>
                                            <option value="07" <?php echo e($month == '07' ? 'selected' : ''); ?>>Juli</option>
                                            <option value="08" <?php echo e($month == '08' ? 'selected' : ''); ?>>Agustus</option>
                                            <option value="09" <?php echo e($month == '09' ? 'selected' : ''); ?>>September</option>
                                            <option value="10" <?php echo e($month == '10' ? 'selected' : ''); ?>>Oktober</option>
                                            <option value="11" <?php echo e($month == '11' ? 'selected' : ''); ?>>November</option>
                                            <option value="12" <?php echo e($month == '12' ? 'selected' : ''); ?>>Desember</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2 pl-0 pl-0">
                                    <div class="form-group">
                                        <strong class="mr-3">Tanggal</strong>
                                        <select class="w-100 pl-1 padding-select groupbyDate" style="border-radius: 3px;" disabled>
                                            <option selected="true" value="null" selected>All</option>
                                            <option value="01" <?php echo e($day == '01' ? 'selected' : ''); ?>>1</option>
                                            <option value="02" <?php echo e($day == '02' ? 'selected' : ''); ?>>2</option>
                                            <option value="03" <?php echo e($day == '03' ? 'selected' : ''); ?>>3</option>
                                            <option value="04" <?php echo e($day == '04' ? 'selected' : ''); ?>>4</option>
                                            <option value="05" <?php echo e($day == '05' ? 'selected' : ''); ?>>5</option>
                                            <option value="06" <?php echo e($day == '06' ? 'selected' : ''); ?>>6</option>
                                            <option value="07" <?php echo e($day == '07' ? 'selected' : ''); ?>>7</option>
                                            <option value="08" <?php echo e($day == '08' ? 'selected' : ''); ?>>8</option>
                                            <option value="09" <?php echo e($day == '09' ? 'selected' : ''); ?>>9</option>
                                            <option value="10" <?php echo e($day == '10' ? 'selected' : ''); ?>>10</option>
                                            <option value="11" <?php echo e($day == '11' ? 'selected' : ''); ?>>11</option>
                                            <option value="12" <?php echo e($day == '12' ? 'selected' : ''); ?>>12</option>
                                            <option value="13" <?php echo e($day == '13' ? 'selected' : ''); ?>>13</option>
                                            <option value="14" <?php echo e($day == '14' ? 'selected' : ''); ?>>14</option>
                                            <option value="15" <?php echo e($day == '15' ? 'selected' : ''); ?>>15</option>
                                            <option value="16" <?php echo e($day == '16' ? 'selected' : ''); ?>>16</option>
                                            <option value="17" <?php echo e($day == '17' ? 'selected' : ''); ?>>17</option>
                                            <option value="18" <?php echo e($day == '18' ? 'selected' : ''); ?>>18</option>
                                            <option value="19" <?php echo e($day == '19' ? 'selected' : ''); ?>>19</option>
                                            <option value="20" <?php echo e($day == '20' ? 'selected' : ''); ?>>20</option>
                                            <option value="21" <?php echo e($day == '21' ? 'selected' : ''); ?>>21</option>
                                            <option value="22" <?php echo e($day == '22' ? 'selected' : ''); ?>>22</option>
                                            <option value="23" <?php echo e($day == '23' ? 'selected' : ''); ?>>23</option>
                                            <option value="24" <?php echo e($day == '24' ? 'selected' : ''); ?>>24</option>
                                            <option value="25" <?php echo e($day == '25' ? 'selected' : ''); ?>>25</option>
                                            <option value="26" <?php echo e($day == '26' ? 'selected' : ''); ?>>26</option>
                                            <option value="27" <?php echo e($day == '27' ? 'selected' : ''); ?>>27</option>
                                            <option value="28" <?php echo e($day == '28' ? 'selected' : ''); ?>>28</option>
                                            <option value="29" <?php echo e($day == '29' ? 'selected' : ''); ?>>29</option>
                                            <option value="30" <?php echo e($day == '30' ? 'selected' : ''); ?>>30</option>
                                            <option value="31" <?php echo e($day == '31' ? 'selected' : ''); ?>>31</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3 mt-4">
                                    <button type="button" class="btn btn-primary" id="search">Cari</button>
                                </div>
                                <div class="col-md-5 mt-4 text-right">
                                    <a href="<?php echo e(route('jurnal_umum.create')); ?>" class="btn btn-primary">Tambah
                                        Jurnal</a>
                                </div>
                            </div>
                        </div>
                        <div class="material-datatables">
                            <table class="table" id="datatables" cellspacing="0" width="100%" class="table table-striped table-no-bordered table-hover">
                                <thead class="text-center">
                                    <tr>
                                        <th rowspan="2">Tanggal</th>
                                        <th rowspan="2" style="width:10%">No Kwitansi</th>
                                        <th rowspan="2">Keterangan</th>
                                        <th colspan="2">Debit</th>
                                        <th colspan="2">Kredit</th>
                                        <th rowspan="2">Aksi</th>
                                    </tr>
                                    <tr>
                                        <th>Akun</th>
                                        <th>Jumlah</th>
                                        <th>Akun</th>
                                        <th>Jumlah</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style="width:15%"><?php echo e($item->date); ?></td>
                                            <td><?php echo e($item->receipt); ?></td>
                                            <td style="width:35%"><?php echo e($item->description); ?></td>
                                            <?php $__currentLoopData = $item->journal()->orderBy('id', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($cek->position == "Debit"): ?>
                                                    <td><?php echo e($cek->account->account_name); ?></td>
                                                    <td>
                                                        Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($cek->amount)),3)))); ?>

                                                    </td>
                                                <?php endif; ?>
                                                <?php if($cek->position == "Kredit"): ?>
                                                    <td><?php echo e($cek->account->account_name); ?></td>
                                                    <td>
                                                        Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($cek->amount)),3)))); ?>

                                                    </td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <td style="width:10%" class="text-center">
                                                <button class="btnEditJournal btn-icon" type="button" rel="tooltip" title="Edit Akun" data-toggle="modal" data-target="#editJournal" id="<?php echo e($item->id); ?>">
                                                    <i class="material-icons" style="color: #9c27b0;font-size:1.1rem;cursor: pointer;">edit</i>
                                                </button>
                                                <button type="button" class="btn-icon remove" id="<?php echo e($item->id); ?>">
                                                        <i class="material-icons" style="color:#f44336;font-size:1.1rem;cursor: pointer;">close</i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- end content-->
                </div>
                <!--  end card  -->
                
            </div>
            <!-- end col-md-12 -->
        </div>
        <!-- end row -->
    </div>
</div>


<div class="modal fade" id="editJournal" tabindex="-1" role="">
    <div class="modal-dialog modal-login" role="document">
        <form class="form" method="POST" action="" id="formEditJournal">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PUT')); ?>

            <div class="modal-content">
                <div class="card card-signup card-plain">
                    <div class="modal-header">
                        <div class="card-header card-header-primary text-center">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                <i class="material-icons">clear</i></button>
                            <h4 class="card-title">Edit Jurnal</h4>
                        </div>
                    </div>
                    <div class="modal-body">
                        <div class="card-body detail">
                            <input type="hidden" name="id_detail">
                            <div class="form-group description">
                                <h6 class="text-dark font-weight-bold m-0">Keterangan</h6>
                                <input type="text" class="form-control" name="description" aria-describedby="ketJurnal"
                                    value="Membeli peralatan secara kredit" required>
                            </div>

                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group receipt">
                                        <h6 class="text-dark font-weight-bold m-0">No Kwitansi</h6>
                                        <input type="text" class="form-control" name="receipt"
                                            aria-describedby="kwitansiJurnal" required>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group date">
                                        <h6 class="text-dark font-weight-bold m-0">Tanggal</h6>
                                        <input type="date" class="form-control" name="date"
                                            aria-describedby="kwitansiJurnal" required>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group debit">
                                        <h6 class="text-dark font-weight-bold m-0">Debit Akun</h6>
                                        <input type="hidden" name="id_debit">
                                        <select class="form-control" name="id_debit_account" required>
                                            <option value="" selected="true">Select Akun</option>
                                            <?php $__currentLoopData = $account; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($a->id); ?>">
                                                    <?php echo e($a->account_name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group amount_debit">
                                        <h6 class="text-dark font-weight-bold m-0">Jumlah</h6>
                                        <input type="text" class="form-control" name="debit"
                                            aria-describedby="amountDebit" data-type="currency" required>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group credit">
                                        <h6 class="text-dark font-weight-bold m-0">Kredit Akun</h6>
                                        <input type="hidden" name="id_credit">
                                        <select class="form-control" name="id_credit_account" required>
                                            <option value="" selected="true">Select Akun</option>
                                            <?php $__currentLoopData = $account; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($a->id); ?>">
                                                    <?php echo e($a->account_name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group amount_credit">
                                        <h6 class="text-dark font-weight-bold m-0">Jumlah</h6>
                                        <input type="text" class="form-control" name="credit"
                                            aria-describedby="amountDebit" data-type="currency" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer justify-content-center">
                    <button type="submit" class="btn btn-primary btn-round">Simpan</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>

<script>
    $(document).ready(function () {
        $('#datatables').DataTable({
            "pagingType"        : "full_numbers",
            "lengthMenu"        : [
                                [10, 25, 50, -1],
                                [10, 25, 50, "All"]
                                ],
            responsive          : true, 
            language            : {
            search              : "_INPUT_",
            searchPlaceholder   : "Cari",
            }
        });
        var table = $('#datatables').DataTable();

        $.ajaxSetup({
            headers : {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        })

        //Delete Record
        table.on('click', '.remove', function(e){
            e.preventDefault();
            var id = $(this).attr('id');

            var url = "<?php echo e(route('jurnal_umum.index')); ?>/"+id;
            Swal.fire({
                title : 'Anda yakin menghapus jurnal?',
                text : 'Anda tidak dapat mengembalikan data yang telah dihapus!',
                icon : 'warning',
                showCancelButton: true,
                cancelButtonText: 'Batal!',
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, hapus!'
            }).then((result) => {
                if(result.value){
                    $.ajax({
                        type        : 'delete',
                        url         : url,
                        dataType    : 'JSON',
                        success     : (response) => {
                            Swal.fire(
                                'Dihapus!',
                                'Jurnal anda telah dihapus.',
                                'success'
                            )
                            $(this).closest('tr').remove();
                        }
                    })
                } else if (result.dismiss === Swal.DismissReason.cancel) {
                    Swal.fire(
                    'Batal',
                    'Data batal dihapus :)',
                    'error'
                    )
                }
            })
        })
    });


    $(document).on('click', '#search', function(e){
        e.preventDefault();
        var year = $("select.groupbyYear").val();
        var month = $("select.groupbyMonth").val();
        var day = $("select.groupbyDate").val();

        var url = "<?php echo e(route('jurnal_umum.index')); ?>?year=" + year;
        if (month != null) {
            url = url + "&month=" + month;
            console.log('month');
        }
        if (month != 'null' && day != 'null') {
            url = url + "&day=" + day;
            console.log('day');
        }
        console.log(url);
        window.location.href = url;
    });

    $(document).ready(function() {
        
        var month = $("select.groupbyMonth").val();
        
        if (month != null) {
            $('select.groupbyDate').prop('disabled', false);
        }
    });
    $(document).on('change', 'select.groupbyMonth', function(e){
        $('select.groupbyDate').prop('disabled', false);
    });

    $(document).on('click', '.btnEditJournal', function(){
        var id = $(this).attr('id');
        $.ajax({
            type        : 'GET',
            url         : '<?php echo url('detailJournal'); ?>',
            data        : {'id' : id},
            dataType    : 'html',
            success     : function(data){
                var servers = $.parseJSON(data);
                $.each(servers, function(index, value){
                    var detail = value.id;
                    var receipt = value.receipt;
                    var date = value.date;
                    var description = value.description;
                    var id_debit = value.journal[0].id;
                    var id_account_debit = value.journal[0].id_account;
                    var rupiah = '';

                    var convert = value.journal[0].amount.toString().split('').reverse().join('');
                    for(var i = 0; i < convert.length; i++) if(i%3 == 0) rupiah += convert.substr(i,3)+',';
                    var amount_debit = 'Rp'+ rupiah.split('',rupiah.length-1).reverse().join('');

                    var id_credit = value.journal[1].id;
                    var id_account_credit = value.journal[1].id_account;

                    var convert_journal = value.journal[1].amount.toString().split('').reverse().join('');
                    console.log(convert);
                    for(var i = 0; i < convert.length_; i++) if(i%3 == 0) rupiah += convert_journal.substr(i,3)+',';
                    var amount_credit = 'Rp'+ rupiah.split('',rupiah.length-1).reverse().join('');

                    console.log(amount_credit);

                    console.log(id_debit);
                    $('div.detail input').val(detail);
                    $('div.receipt input').val(receipt);
                    $('div.date input').val(date);
                    $('div.description input').val(description);
                    $('div.debit select').val(id_account_debit);
                    $('div.debit input').val(id_debit);
                    $('div.amount_debit input').val(amount_debit);
                    $('div.credit select').val(id_account_credit);
                    $('div.credit input').val(id_credit);
                    $('div.amount_credit input').val(amount_credit);
                })
            }, error    : function(){
                
            },
        });
        var action = "<?php echo e(route('jurnal.update')); ?>";
            $('#formEditJournal').attr('action',action);
    })
</script>
<script>
    // Jquery Dependency
    $("input[data-type='currency']").on({
        keyup: function() {
            formatCurrency($(this));
        },
        click : function(){
            formatCurrency($(this));
        }
    });

    function formatNumber(n) {
    // format number 1000000 to 1,234,567
    return n.replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")
    }

    function formatCurrency(input, blur) {
    // appends $ to value, validates decimal side
    // and puts cursor back in right position.
    
    // get input value
    var input_val = input.val();
    
    // don't validate empty input
    if (input_val === "") { return; }
    
    // original length
    var original_len = input_val.length;

    // initial caret position 
    var caret_pos = input.prop("selectionStart");
        
    // check for decimal
    if (input_val.indexOf(".") >= 0) {

        // get position of first decimal
        // this prevents multiple decimals from
        // being entered
        var decimal_pos = input_val.indexOf(".");

        // split number by decimal point
        var left_side = input_val.substring(0, decimal_pos);
        var right_side = input_val.substring(decimal_pos);

        // add commas to left side of number
        left_side = formatNumber(left_side);

        // validate right side
        right_side = formatNumber(right_side);
        
        // Limit decimal to only 2 digits
        right_side = right_side.substring(0, 2);

        // join number by .
        input_val = "Rp" + left_side + "." + right_side;

    } else {
        // no decimal entered
        // add commas to number
        // remove all non-digits
        // console.log('input_val', input_val)
        input_val = formatNumber(input_val);
        input_val = "Rp" + input_val;
        
    }
    
    // send updated string to input
    input.val(input_val);

    // put caret back in the right position
    var updated_len = input_val.length;
    caret_pos = updated_len - original_len + caret_pos;
    input[0].setSelectionRange(caret_pos, caret_pos);
    }
</script>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user/layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UI-TA\resources\views/user/jurnalUmum.blade.php ENDPATH**/ ?>
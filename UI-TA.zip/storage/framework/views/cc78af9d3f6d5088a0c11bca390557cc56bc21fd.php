<!DOCTYPE html>
<html>
<head>
    <title>Welcome Email</title>
</head>

<body>
<h2>Welcome to the site <?php echo e($user['email']); ?></h2>
<br/>
    Your registered email-id is <?php echo e($user['password']); ?>

    Your registered name is <?php echo e($user['name']); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\UI-TA\resources\views/email/registerSucces.blade.php ENDPATH**/ ?>
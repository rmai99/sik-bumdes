<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-sm-7 col-lg-5">
            <div class="card">
                <div class="card">
                    <div class="card-body">
                        <div class="text-center mt-3 mb-1">
                            <h3> SIK <strong> BUMDES </strong> </h3>
                        </div>
                            <?php
                                @error
                            ?>
                        <form method="POST" action="<?php echo e(route('register')); ?>">
                            <?php echo csrf_field(); ?>
                            <h4 class="font-weight-bold">Daftar</h2>
                            <p class="mb-0 font-14">Nama Perusahaan</p>
                            <div class="input-group mb-2 ">
                                <div class="input-group-append">
                                    <div class="input-group-text">
                                        <i class=" material-icons" style="font-size:18px">
                                            business
                                        </i>
                                    </div>
                                </div>
                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name"
                                    placeholder="Nama Perusahaan" autofocus>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <p class="mb-0 font-14">Alamat Perusahaan</p>
                            <div class="input-group mb-2">
                                <div class="input-group-append">
                                    <div class="input-group-text">
                                        <i class=" material-icons" style="font-size:18px">
                                            home
                                        </i>
                                    </div>
                                </div>
                                <input id="address" type="text"
                                    class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="address"
                                    value="<?php echo e(old('address')); ?>" required autocomplete="address"
                                    placeholder="Alamat Perusahaan">
                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <p class="mb-0 font-14">Nomor Telepon</p>
                            <div class="input-group mb-2">
                                <div class="input-group-append">
                                    <div class="input-group-text">
                                        <i class=" material-icons" style="font-size:18px">
                                            call
                                        </i>
                                    </div>
                                </div>
                                <input id="phone_number" type="text"
                                    class="form-control <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone_number"
                                    value="<?php echo e(old('phone_number')); ?>" required autocomplete="phone_number"
                                    placeholder="Nomor Telepon">
                                    <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <p class="mb-0 font-14">Email</p>
                            <div class="input-group mb-2">
                                <div class="input-group-append">
                                    <div class="input-group-text">
                                        <i class=" material-icons" style="font-size:18px">
                                            email
                                        </i>
                                    </div>
                                </div>
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email"
                                    placeholder="Email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="input-group mb-2">
                                <input id="role" type="hidden" name="role" value="owner">
                            </div>
                            <p class="mb-0 font-14">Password</p>
                            <div class="input-group mb-2">
                                <div class="input-group-append">
                                    <div class="input-group-text">
                                        <i class="material-icons" style="font-size:18px">
                                            lock
                                        </i>
                                    </div>
                                </div>
                                <input id="password" type="password"
                                    class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                                    required autocomplete="new-password" placeholder="Password">
                                    <?php if($errors->has('password')): ?>
                                        <span class="invalid">
                                            <strong><?php echo e($errors->first('password')); ?><strong>
                                        </span>
                                    <?php endif; ?> 
                                </div>
                            <p class="mb-0 font-14">Konfirmasi Password</p>
                            <div class="input-group mb-2">
                                <div class="input-group-append">
                                    <div class="input-group-text">
                                        <i class="material-icons" style="font-size:18px">
                                            lock
                                        </i>
                                    </div>
                                </div>
                                <input id="password-confirm" type="password" class="form-control"
                                    name="password_confirmation" required autocomplete="new-password"
                                    placeholder="Confirm Password">
                            </div>
                            <div class="row mt-4">
                                <div class="col-12 d-flex justify-content-center">
                                    <button type="submit" class="btn btn-register mb-3">DAFTAR</button>
                                </div>
                            </div>
                        </form>
                        <div class="row">
                            <div class="col-12 text-center">
                                <a href="<?php echo e(route('login')); ?>"
                                    class="text-center text-dark">Sudah Punya Akun? <strong>Masuk!</strong></a>
                            </div>
                        </div>
                    </div>
                    <!-- /.form-box -->
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UI-TA\resources\views/auth/register.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Ubah kata Sandi'); ?>

<?php $__env->startSection('title-page', 'Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header card-header-primary">
            <h4 class="card-title">Ubah Kata Sandi</h4>
            
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('ganti_password.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row justify-content-center">
                    <div class="col-md-7">
                        <div class="form-group">
                            <h6 class="text-dark font-weight-bold m-0">Kata Sandi</h6>
                            <input type="password" class="form-control" name="current_password">
                        </div>
                        <?php if($errors->has('current_password')): ?>
                            <span class="invalid">
                                <?php echo e($errors->first('current_password')); ?>

                            </span>
                        <?php endif; ?> 
                    </div>
                    <div class="col-md-7">
                        <div class="form-group">
                            <h6 class="text-dark font-weight-bold m-0">Kata Sandi Baru</h6>
                            <input type="password" class="form-control" name="new_password">
                        </div>
                        <?php if($errors->has('new_password')): ?>
                            <span class="invalid">
                                <?php echo e($errors->first('new_password')); ?>

                            </span>
                        <?php endif; ?> 
                    </div>
                    <div class="col-md-7">
                        <div class="form-group">
                            <h6 class="text-dark font-weight-bold m-0">Konfirmasi Kata Sandi Baru</h6>
                            <input type="password" class="form-control" name="new_confirm_password">
                        </div>
                        <?php if($errors->has('new_confirm_password')): ?>
                            <span class="invalid">
                                <?php echo e($errors->first('new_confirm_password')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-7">
                        <button type="submit" class="btn btn-primary pull-right">SIMPAN</button>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user/layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UI-TA\resources\views/user/changePassword.blade.php ENDPATH**/ ?>
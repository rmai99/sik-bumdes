<?php $__env->startSection('title', 'Upgrade to PRO'); ?>

<?php $__env->startSection('title-page', 'Upgrade to PRO'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
      <div class="col-md-8 ml-auto mr-auto">
        <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title">Material Dashboard PRO</h4>
            <p class="card-category">Are you looking for more components? Please check our Premium Version of Material Dashboard.</p>
          </div>
          <div class="card-body">
            <div class="table-responsive table-upgrade">
              <table class="table">
                <thead>
                  <tr>
                    <th style="background: none!important;color: #3c4858;"></th>
                    <th class="text-center" style="background: none!important;color: #3c4858;">Free</th>
                    <th class="text-center" style="background: none!important;color: #3c4858;">PRO</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Components</td>
                    <td class="text-center">60</td>
                    <td class="text-center">200</td>
                  </tr>
                  <tr>
                    <td>Plugins</td>
                    <td class="text-center">2</td>
                    <td class="text-center">15</td>
                  </tr>
                  <tr>
                    <td>Example Pages</td>
                    <td class="text-center">3</td>
                    <td class="text-center">27</td>
                  </tr>
                  <tr>
                    <td>Login, Register, Pricing, Lock Pages</td>
                    <td class="text-center">
                        <span class="material-icons" style="color:#f44336;font-size:1.1rem;">close</span>
                    </td>
                    <td class="text-center">
                        <span class="material-icons" style="color:#4caf50;font-size:1.1rem;">check</span>
                    </td>
                  </tr>
                  <tr>
                    <td>DataTables, VectorMap, SweetAlert, Wizard, jQueryValidation, FullCalendar etc...</td>
                    <td class="text-center">
                        <span class="material-icons" style="color:#f44336;font-size:1.1rem;">close</span>
                    </td>
                    <td class="text-center">
                        <span class="material-icons" style="color:#4caf50;font-size:1.1rem;">check</span>
                    </td>
                  </tr>
                  <tr>
                    <td>Mini Sidebar</td>
                    <td class="text-center">
                        <span class="material-icons" style="color:#f44336;font-size:1.1rem;">close</span>
                    </td>
                    <td class="text-center">
                        <span class="material-icons" style="color:#4caf50;font-size:1.1rem;">check</span>
                    </td>
                  </tr>
                  <tr>
                    <td>Premium Support</td>
                    <td class="text-center">
                        <span class="material-icons" style="color:#f44336;font-size:1.1rem;">close</span>
                    </td>
                    <td class="text-center">
                        <span class="material-icons" style="color:#4caf50;font-size:1.1rem;">check</span>
                    </td>
                  </tr>
                  <tr>
                    <td></td>
                    <td class="text-center">Free</td>
                    <td class="text-center">Just $49</td>
                  </tr>
                  <tr>
                    <td class="text-center"></td>
                    <td class="text-center">
                      <a href="#" class="btn btn-round btn-fill btn-default disabled">Current Version</a>
                    </td>
                    <td class="text-center">
                      <a target="_blank" href="http://www.creative-tim.com/product/material-dashboard-pro/?ref=md-free-upgrade-live" class="btn btn-round btn-fill btn-info">Upgrade to PRO</a>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user/layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UI-TA\resources\views/home.blade.php ENDPATH**/ ?>
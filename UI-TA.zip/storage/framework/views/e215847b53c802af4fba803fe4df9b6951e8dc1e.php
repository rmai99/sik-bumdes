<?php $__env->startSection('title', 'Bisnis'); ?>

<?php $__env->startSection('title-page', 'Bisnis'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-primary">
                    <h4 class="card-title ">Bisnis</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-12 text-right">
                            <a href="" class="btn btn-sm btn-primary addBusiness">Tambah Bisnis</a>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-no-bordered table-hover" id="datatables">
                            <thead class=" text-primary">
                                <th>
                                    Nama
                                </th>
                                <th>
                                    Tanggal Dibentuk
                                </th>
                                <th class="disabled-sorting text-right">
                                    Actions
                                </th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $business; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php echo e($item->business_name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($item->created_at); ?>

                                        </td>
                                        <td class="text-right">
                                            <button type="button" class="edit btn-icon" id="<?php echo e($item->id); ?>" rel="tooltip" title="Edit Akun" data-toggle="modal" data-target="#editBusiness">
                                                <i class="material-icons" style="color: #9c27b0;font-size:1.1rem;cursor: pointer;">edit</i>
                                            </button>
                                            <button type="button" class="btn-icon remove" id="<?php echo e($item->id); ?>" >
                                                    <i class="material-icons" style="color:#f44336;font-size:1.1rem;cursor: pointer;">close</i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="tambahBisnis" tabindex="-1" role="">
    <div class="modal-dialog modal-login" role="document">
        <div class="modal-content">
            <form class="form" method="POST" action="<?php echo e(route('bisnis.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="card card-signup card-plain">
                    <div class="modal-header">
                        <div class="card-header card-header-primary text-center">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                <i class="material-icons">clear</i></button>
                            <h4 class="card-title">Tambah Bisnis</h4>
                        </div>
                    </div>
                    <div class="modal-body">
                        <div class="card-body">

                            <div class="form-group">
                                <h6 class="text-dark font-weight-bold m-0">Nama</h6>
                                <input type="text" class="form-control" name="business_name" aria-describedby="date" placeholder="" value="<?php echo e(old('business_name')); ?>" required>
                                <?php $__errorArgs = ['business_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary btn-round text-center">Simpan</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>


<div class="modal fade" id="editBusiness" tabindex="-1" role="">
    <div class="modal-dialog modal-login" role="document">
        <div class="modal-content">
            <form class="form" method="POST" action="" id="formEdit">
                <?php echo e(method_field('PUT')); ?>

                <?php echo csrf_field(); ?>
                <div class="card card-signup card-plain">
                    <div class="modal-header">
                        <div class="card-header card-header-primary text-center">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                <i class="material-icons">clear</i></button>
                            <h4 class="card-title">Edit Bisnis</h4>
                        </div>
                    </div>
                    <div class="modal-body">
                        <div class="card-body">
                            <div class="form-group name">
                                <h6 class="text-dark font-weight-bold m-0">Nama</h6>
                                <input type="text" class="form-control" aria-describedby="name" name="name" id="name">
                                <input type="hidden" class="form-control" name="id" id="formEditId">
                            </div>
                            <?php if($errors->has('name')): ?>
                                <span class="invalid">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary btn-round text-center">Simpan</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>`

<?php $__env->startPush('js'); ?>
<script>
    $(document).ready(function () {
        <?php if($errors->has('disable')): ?>
            swal.fire({
                title: "Ubah Akun Menjadi PRO",
                icon: "warning",
                closeOnClickOutside: false,
                showConfirmButton: false,
                // timer       :2000,
                footer: '<a href="<?php echo e(route('upgrade')); ?>">Upgrade Account?</a>'
            })
        <?php endif; ?>
        <?php if($errors->has('business_name')): ?>
            $('#tambahBisnis').modal('show');
        <?php endif; ?>
        <?php if($errors->has('name')): ?>
            $('#editBusiness').modal('show');
            var name = "<?php echo e(old('name')); ?>";
            console.log("maidaa");
            $('#name').val(name);
            
            var id = "<?php echo e(old('id')); ?>";
            var action = "<?php echo e(route('bisnis.index')); ?>/"+id;
            $('#formEdit').attr('action', action);
        <?php endif; ?>
        
        $('#datatables').DataTable({
            "pagingType"        : "full_numbers",
            "lengthMenu"        : [
                                [10, 25, 50, -1],
                                [10, 25, 50, "All"]
                                ],
            responsive          : true, 
            language            : {
            search              : "_INPUT_",
            searchPlaceholder   : "Cari",
            }
        });

        var table = $('#datatables').DataTable();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        
        // Delete a record
        table.on('click', '.remove', function(e) {
            e.preventDefault();
            var id = $(this).attr('id');
            
            // console.log(sid);
            var url = "<?php echo e(route('bisnis.index')); ?>/"+id;
            Swal.fire({
                title: 'Anda yakin ingin menghapus bisnis?',
                text: "Data akan dihapus secara permanen",
                icon: 'warning',
                showCancelButton: true,
                cancelButtonText: 'Batal!',
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, hapus!'
            }).then((result) => {
                if (result.value) {
                    $.ajax({
                        type: "delete",
                        url: url,
                        dataType: "json",
                        success: (response) => {
                            Swal.fire(
                            'Dihapus!',
                            'Bisnis telah dihapus.',
                            'success'
                            )
                            $(this).closest('tr').remove();
                            var url = "<?php echo e(route('bisnis.create')); ?>";
                            window.location.href = url;
                        }, error    : function(){
                            swal.fire({
                                title: "Tidak dapat menghapus bisnis",
                                icon: "warning",
                                closeOnClickOutside: false,
                                showConfirmButton: false,
                                timer       :2000,
                            })
                        },
                    });
                } else if (result.dismiss === Swal.DismissReason.cancel) {
                    Swal.fire(
                    'Batal',
                    'Data batal dihapus :)',
                    'error'
                    )
                }
            })
        });
    });
    
    $(document).ready(function () {
        $(document).on('click', '.edit', function() {
            var id = $(this).attr('id');
            $('#formEditId').val(id);
            $.ajax({
                type        : 'GET',
                url         : '<?php echo url('detail_bisnis'); ?>',
                data        : {'id' : id},
                dataType    : 'html',
                success     : function(data){
                    var servers = $.parseJSON(data);
                    $.each(servers, function(index, value){
                        var name = value.business_name;
                        
                        $('#name').val(name);
                    });
                }
            })
            var action = "<?php echo e(route('bisnis.index')); ?>/"+id;
            $('#formEdit').attr('action', action);
        });

        $(document).on('click', '.addBusiness', function(e) {
            e.preventDefault();
            $.ajax({
                type        : 'GET',
                url         : '<?php echo url('isPro'); ?>',
                dataType    : 'html',
                success     : function(data){
                    var servers = $.parseJSON(data);
                    // console.log(servers);
                    // console.log(servers.result);
                    if (servers.result == "REGULER") {
                        swal.fire({
                            title: "Ubah Akun Perusahaan Menjadi PRO",
                            icon: "warning",
                            closeOnClickOutside: false,
                            showConfirmButton: false,
                            // timer       :2000,
                            footer: '<a href="<?php echo e(route('upgrade')); ?>">Upgrade Akun Perusahaan?</a>'
                        });
                    }else {
                        $('#tambahBisnis').modal('show')
                    }
                }, error    : function(){

                },
            })
        });
    });
</script>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user/layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UI-TA\resources\views/user/bisnis.blade.php ENDPATH**/ ?>
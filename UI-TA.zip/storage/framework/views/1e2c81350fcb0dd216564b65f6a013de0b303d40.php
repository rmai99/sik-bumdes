<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('title-page', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $month = null;
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats mt-0">
                <div class="card-header card-header-icon pb-4 pt-4">
                    <div class="card-icon" style="background: linear-gradient(60deg, #ffa726, #fb8c00);">
                        <i class="material-icons">account_balance_wallet</i>
                    </div>
                    <p class="card-category">Saldo Kas</p>
                    <h3 class="card-title">
                        <?php echo e($sum); ?>

                    </h3>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats mt-0">
                <div class="card-header card-header-success card-header-icon pb-4 pt-4">
                    <div class="card-icon">
                        <i class="material-icons">money</i>
                    </div>
                    <p class="card-category">Laba Rugi</p>
                    <h3 class="card-title"><?php echo e($saldo_berjalan); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats mt-0">
                <div class="card-header card-header-danger card-header-icon pb-4 pt-4">
                    <div class="card-icon">
                        <i class="material-icons">receipt</i>
                    </div>
                    <p class="card-category">Transaksi</p>
                    <h3 class="card-title"><?php echo e($transaction); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats mt-0">
                <div class="card-header card-header-info card-header-icon pb-4 pt-4">
                    <div class="card-icon">
                        <i class="material-icons">account_balance_wallet</i>
                    </div>
                    <p class="card-category">Akun</p>
                    <h3 class="card-title"><?php echo e($account); ?></h3>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-6 col-md-12">
            <div class="card">
                <div class="card-header card-header-warning m-0">
                    <h4 class="card-title">Transaksi</h4>
                     <p class="card-category">Transaksi Terbaru</p> 
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row">
                            <div class="col-8">
                                <p class="font-weight-bold mb-0"><?php echo e($item->description); ?></p>
                            </div>
                            <div class="col-4">
                                <p class="d-flex justify-content-end mb-0 font-20">
                                    Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($item->journal[0]->amount)),3)))); ?>

                                </p>
                            </div>
                            <div class="col">
                                <p class="font-14"><?php echo e(strftime("%d %B %G", strtotime($item->date))); ?></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-md-12 card card-primary card-outline">
            <div class="card-header d-flex justify-content-between">
                <h3 class="card-title d-flex align-items-center">
                    Arus Akun Kas
                </h3>
                <div class="btn-group" data-toggle="btn-toggle">
                    <button onclick="myFunction()" class="btn btn-default btn-sm" style="background: #66bb6a">Filter</button>
                </div>
            </div>
            <div class="card-body">
                <div id="myDIV" class="card-filter">
                    <h6>Periode</h6>
                    <div class="row">
                        <div class="col-6">
                            <select class="form-control period" style="border: none; background-color:transparent;">
                                <option>Bulanan</option>
                                <option>Harian</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <select name="" id="yearFilter" class="form-control" style="border: none; background-color:transparent;">
                                <option value="" selected disabled>-- YEAR --</option>
                                <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($y->year); ?>" <?php echo e($year == $y->year ? 'selected' : ''); ?>><?php echo e($y->year); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-12 pt-2">
                            <select class="w-100 pl-1 padding-select groupbyMonth" style="border-radius: 3px" id="period-daily">
                                <option value="0" disabled="true" selected="true">Month</option>
                                <option value="01" <?php echo e($month == '01' ? 'selected' : ''); ?>>Januari</option>
                                <option value="02" <?php echo e($month == '02' ? 'selected' : ''); ?>>Februari</option>
                                <option value="03" <?php echo e($month == '03' ? 'selected' : ''); ?>>Maret</option>
                                <option value="04" <?php echo e($month == '04' ? 'selected' : ''); ?>>April</option>
                                <option value="05" <?php echo e($month == '05' ? 'selected' : ''); ?>>Mei</option>
                                <option value="06" <?php echo e($month == '06' ? 'selected' : ''); ?>>Juni</option>
                                <option value="07" <?php echo e($month == '07' ? 'selected' : ''); ?>>Juli</option>
                                <option value="08" <?php echo e($month == '08' ? 'selected' : ''); ?>>Agustus</option>
                                <option value="09" <?php echo e($month == '09' ? 'selected' : ''); ?>>September</option>
                                <option value="10" <?php echo e($month == '10' ? 'selected' : ''); ?>>Oktober</option>
                                <option value="11" <?php echo e($month == '11' ? 'selected' : ''); ?>>November</option>
                                <option value="12" <?php echo e($month == '12' ? 'selected' : ''); ?>>Desember</option>
                            </select>
                        </div>
                        <div class="col-12 text-center pt-2">
                            <button type="button" class="btn btn-primary btn-sm btnFIlter">Filter</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <canvas id="myChart" class="chartjs-render-monitor mt-3"
                style="display: block"></canvas>
            </div>
            <!-- /.card-body-->
        </div>
    </div>
    
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $(function () {
            'use strict'

            var ticksStyle = {
                fontColor: '#495057',
                fontStyle: 'bold'
            }

            var mode = 'index'
            var intersect = true

            var $salesChart = $('#laba-rugi')
            
            var salesChart = new Chart($salesChart, {
                type: 'bar',
                data: {
                    labels: ['JAN', 'FEB', 'MAR', 'APR', 'MEI', 'JUL', 'AGT', 'SEP', 'OKT', 'NOV', 'DES'],
                    datasets: [{
                        backgroundColor: ['#109CF1', '#FFB946', '#F7685B', '#2ED47A', '#885AF8', '#47C7EB', '#109CF1', '#FFB946', '#F7685B', '#2ED47A', '#885AF8', '#47C7EB'],
                        borderColor: '#007bff',
                        data: [1000, 2000, 3000, 2500, 2700, 2500, 3000, 500, 200, 100, 400, 500, 500]
                    }, ]
                },
                options: {
                    maintainAspectRatio: false,
                    tooltips: {
                        mode: mode,
                        intersect: intersect
                    },
                    hover: {
                        mode: mode,
                        intersect: intersect
                    },
                    legend: {
                        display: false
                    },
                    scales: {
                        yAxes: [{
                            // display: false,
                            gridLines: {
                                display: true,
                                lineWidth: '4px',
                                color: 'rgba(0, 0, 0, .2)',
                                zeroLineColor: 'transparent'
                            },
                            ticks: $.extend({
                                beginAtZero: true,

                                // Include a dollar sign in the ticks
                                callback: function (value, index, values) {
                                    if (value >= 1000) {
                                        value /= 1000
                                        value += 'k'
                                    }
                                    return 'Rp' + value
                                }
                            }, ticksStyle)
                        }],
                        xAxes: [{
                            display: true,
                            gridLines: {
                                display: false
                            },
                            ticks: ticksStyle
                        }]
                    }
                }
            })

            $.ajax({
                type: "GET",
                url: "<?php echo e(route('cash_flow')); ?>",
                dataType: "json",
                success: function(data){
                    // console.log(data.bulan);
                    window.myChart = new Chart(document.getElementById('myChart'), {
                    type: 'bar',
                    data: {
                        labels: data.bulan,
                        datasets: [{
                            label: 'cash in',
                            data: data.in,
                            backgroundColor: '#2ED47A',
                            borderColor: '#2ED47A',
                            borderWidth: 0
                        },
                        {
                            label: 'cash out',
                            data: data.out,
                            backgroundColor: '#47C7EB',
                            borderColor: '#47C7EB',
                            borderWidth: 0
                        }
                        ]
                    },
                    options: {
                        scales: {
                            yAxes: [{
                            // display: false,
                            gridLines: {
                                display: true,
                                lineWidth: '4px',
                                color: 'rgba(0, 0, 0, .2)',
                                zeroLineColor: 'transparent'
                            },
                            ticks: $.extend({
                                // Include a dollar sign in the ticks
                                callback: function (value, index, values) {
                                    if (value >= 1000000) {
                                        value /= 1000000
                                        value += 'jt'
                                        return 'Rp' + value
                                    } else if(value <= -1000000){
                                        value /= 1000000*-1
                                        value += 'jt'
                                        return '-Rp' + value
                                    }
                                }
                            }, ticksStyle)
                        }],
                        xAxes: [{
                            stacked: true,
                            ticks: {
                            beginAtZero: true
                            }
                        }]

                        }
                    }
                    });
                }
            })

            $(document).on('click', '.btnFIlter', function(e){
                e.preventDefault();
                var year = $('#yearFilter').val();
                var month = $('#period-daily').val();
                var period = $('.period').val();
                
                if (period == "Bulanan") {
                    window.myChart.destroy();
                    var path = "<?php echo e(route('cash_flow')); ?>?year="+year;
                    $.ajax({
                    type: "GET",
                    url: path,
                    dataType: "json",
                    success: function(data){
                        // console.log(data.bulan);
                        window.myChart = new Chart(document.getElementById('myChart'), {
                        type: 'bar',
                        data: {
                            labels: data.bulan,
                            datasets: [{
                                label: 'cash in',
                                data: data.in,
                                backgroundColor: '#2ED47A',
                                borderColor: '#2ED47A',
                                borderWidth: 0
                            },
                            {
                                label: 'cash out',
                                data: data.out,
                                backgroundColor: '#47C7EB',
                                borderColor: '#47C7EB',
                                borderWidth: 0
                            }
                            ]
                        },
                        options: {
                            scales: {
                                yAxes: [{
                                // display: false,
                                gridLines: {
                                    display: true,
                                    lineWidth: '4px',
                                    color: 'rgba(0, 0, 0, .2)',
                                    zeroLineColor: 'transparent'
                                },
                                ticks: $.extend({
                                    // Include a dollar sign in the ticks
                                    callback: function (value, index, values) {
                                        if (value >= 1000000) {
                                            value /= 1000000
                                            value += 'jt'
                                            return 'Rp' + value
                                        } else if(value <= -1000000){
                                            value /= 1000000*-1
                                            value += 'jt'
                                            return '-Rp' + value
                                        }
                                    }
                                }, ticksStyle)
                            }],
                            xAxes: [{
                                stacked: true,
                                ticks: {
                                beginAtZero: true
                                }
                            }]
    
                            }
                        }
                        });
                    }
                });  
                
                }
                else if(period == "Harian"){
                    window.myChart.destroy();
                    var path = "<?php echo e(route('cash_flow_daily')); ?>/"+year+"-"+month;
                    console.log(path);
                    $.ajax({
                    type: "GET",
                    url: path,
                    dataType: "json",
                    success: function(data){
                        // console.log(data.bulan);
                        window.myChart = new Chart(document.getElementById('myChart'), {
                        type: 'line',
                        data: {
                            labels: data.day,
                            datasets: [{
                                fill : false,
                                label: 'cash in',
                                data: data.in,
                                borderWidth         : 2,
                                lineTension         : 0,
                                spanGaps : true,
                                borderColor         : '#2ED47A',
                                pointRadius         : 3,
                                pointHoverRadius    : 7,
                                pointColor          : '#2ED47A',
                                pointBackgroundColor: '#2ED47A',
                            },
                            {
                                fill : false,
                                label: 'cash out',
                                data: data.out,
                                borderWidth         : 2,
                                lineTension         : 0,
                                spanGaps : true,
                                borderColor         : '#47C7EB',
                                pointRadius         : 3,
                                pointHoverRadius    : 7,
                                pointColor          : '#47C7EB',
                                pointBackgroundColor: '#47C7EB',
                            }
                            ]
                        },
                        options: {
                            responsive              : true,
                            scales: {
                                yAxes: [{
                                // display: false,
                                gridLines: {
                                    display: true,
                                    lineWidth: '4px',
                                    color: 'rgba(0, 0, 0, .2)',
                                    zeroLineColor: 'transparent'
                                },
                                ticks: $.extend({
                                    // Include a dollar sign in the ticks
                                    callback: function (value, index, values) {
                                        if (value >= 1000000) {
                                            value /= 1000000
                                            value += 'jt'
                                            return 'Rp' + value
                                        } else if(value <= -1000000){
                                            value /= 1000000*-1
                                            value += 'jt'
                                            return '-Rp' + value
                                        }
                                    }
                                }, ticksStyle)
                            }],
                            xAxes: [{
                                stacked: true,
                                ticks: {
                                beginAtZero: true
                                }
                            }]
    
                            }
                        }
                        });
                    }
                });
                }
                
            });

            //---------------------
            //- STACKED BAR CHART -
            //---------------------
            var stackedBarChartCanvas = $('#stackedBarChart').get(0).getContext('2d')

            var stackedBarChartOptions = {
            responsive              : true,
            maintainAspectRatio     : false,
            scales: {
                xAxes: [{
                stacked: true,
                }],
                yAxes: [{
                stacked: true
                }]
            }
            }

            var stackedBarChart = new Chart(stackedBarChartCanvas, {
            type: 'bar',
            options: stackedBarChartOptions
            })
        })
        document.getElementById("myDIV").style.display = "none";
        function myFunction() {
            var x = document.getElementById("myDIV");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }

        document.getElementById("period-daily").style.display = "none";            
        $(document).on('change', 'select.period', function(e){
            var x = document.getElementById("period-daily");
            var period = $("select.period").val();
            if(period == "Harian"){
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        });
        

    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user/layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UI-TA\resources\views/user/dashboard.blade.php ENDPATH**/ ?>
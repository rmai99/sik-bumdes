<ul class="nav">    
    <li class="nav-item <?php echo e(Request::segment(1) === 'null' ? 'active' : null); ?>  ">
        <a href="<?php echo e(route('admin.index')); ?>" class="nav-link">
            <i class="material-icons">dashboard</i>
            <p>Dashboard</p>
        </a>
    </li>
    <li class="nav-item <?php echo e(Request::segment(2) === 'user' ? 'active' : null); ?>">
        <a class="nav-link" href="<?php echo e(route('admin.user.index')); ?>">
            <i class="material-icons">content_paste</i>
            <p>Pengguna</p>
        </a>
    </li>
    <?php if(auth()->check() && auth()->user()->hasRole('super admin')): ?>
    <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#profile" aria-expanded="true">
            <i class="material-icons">person</i>
            <p> Admin
                <b class="caret"></b>
            </p>
        </a>
        <div class="collapse <?php echo e(Request::segment(2) === 'manajemen_admin' || Request::segment(2) === 'tambah_admin' ? 'show' : null); ?>" id="profile">
            <ul class="nav m-0">
                <li class="nav-item <?php echo e(Request::segment(2) === 'manajemen_admin' ? 'active' : null); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.manajemen_admin.index')); ?>">
                        <span class="sidebar-mini"> UP </span>
                        <span class="sidebar-normal"> Daftar Admin </span>
                    </a>
                </li>
            </ul>
        </div>
    </li>
    <?php endif; ?>
</ul><?php /**PATH C:\xampp\htdocs\UI-TA\resources\views/admin/layout/sidebar.blade.php ENDPATH**/ ?>
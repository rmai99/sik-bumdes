<?php $__env->startSection('title', 'Buku Besar'); ?>

<?php $__env->startSection('title-page', 'Buku Besar'); ?>

<?php $__env->startSection('content'); ?>
<?php
    if(isset($_GET['year'], $_GET['akun'])){
        $year = $_GET['year'];
        $akun = $_GET['akun'];
    } else {
        $year = date('Y');
        $akun = $account;
    }

    $saldo_awal = $log['saldo_awal'];
    $saldo_akhir = $log['saldo_awal'];
    $debit = 0;
    $kredit = 0;
    setlocale(LC_ALL, 'id_ID')
?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="header text-center mt-2">
                        <h3 class="title" style="font-weight: 400;">Buku Besar</h3>
                        <p><strong>Periode</strong> <?php echo e($year); ?> </p>
                    </div>
                    <div class="card-body">
                        <div class="toolbar">
                            <div class="row d-flex">
                                <div class="col-md-2 pr-2">
                                    <div class="form-group">
                                        <strong class="mr-3">Tahun</strong>
                                        <select class="w-100 pl-1 padding-select groupbyYear" style="border-radius: 3px;">
                                            <option value="0" disabled="true" selected="true">Tahun</option>
                                            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($y->year); ?>" <?php echo e($year == $y->year ? 'selected' : ''); ?>><?php echo e($y->year); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3 pl-md-2 pr-2">
                                    <div class="form-group">
                                        <strong class="mr-3">Akun</strong>
                                        <select class="w-100 pl-1 padding-select groupbyAccount" id="" style="border-radius: 3px;">
                                            <option value="0" selected disabled>Akun</option>
                                            <?php $__currentLoopData = $akuns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($a->id); ?>" <?php echo e($akun == $a->id ? 'selected' : ''); ?>><?php echo e($a->account_code); ?> - <?php echo e($a->account_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3 mt-4">
                                    <button type="button" class="btn btn-primary" id="search">Cari</button>
                                </div>  
                            </div>
                            <div class="row mt-4">
                                <div class="col-md-6">
                                    <div class="row d-flex">
                                        <div class="col-sm-6 col-md-6">
                                            Nama Akun
                                        </div>
                                        <div class="col-md-6">
                                            <strong> : <?php echo e($log['nama_akun']); ?></strong>
                                        </div>
                                    </div>
                                    <div class="row d-flex">
                                        <div class="col-md-6">
                                            Kode Akun
                                        </div>
                                        <div class="col-md-6">
                                            <strong> : <?php echo e($log['kode_akun']); ?></strong>
                                        </div>
                                    </div>
                                    <div class="row d-flex">
                                        <div class="col-md-6">
                                            Posisi Normal
                                        </div>
                                        <div class="col-md-6">
                                            <strong> : <?php echo e($log['position']); ?></strong>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="row d-flex">
                                        <div class="col-lg-6 col-md-6">
                                            Saldo Awal
                                        </div>
                                        <div class="col-lg-6 col-md-6">
                                            <strong> : Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($saldo_awal)),3)))); ?></strong>
                                        </div>
                                    </div>
                                    <div class="row d-flex">
                                        <div class="col-md-6">
                                            Saldo Akhir
                                        </div>
                                        <div class="col-md-6">
                                            : <strong id="saldo_akhir"></strong>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="material-datatables mt-4">
                            <table id="generalLedger" class="table table-striped table-no-bordered table-hover"
                                cellspacing="0" width="100%" style="width:100%">
                                <thead class="text-center">
                                    <tr>
                                        <th rowspan="2" style="width:15%">Tanggal</th>
                                        <th rowspan="2" style="width:40%">Keterangan</th>
                                        <th colspan="2" class="text-center">Posisi</th>
                                        <th rowspan="2">Saldo</th>
                                    </tr>
                                    <tr>
                                        <th class="text-center">Debit</th>
                                        <th class="text-center">Kredit</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?php echo e(strftime("%d %B %G", strtotime($log['date']))); ?> </td>
                                        <td>Saldo Awal</td>
                                        <td></td>
                                        <td></td>
                                        <td>
                                            Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($log['saldo_awal'])),3)))); ?>

                                        </td>
                                    </tr>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(strftime("%d %B %G", strtotime($d->detail->date))); ?></td>
                                        <td><?php echo e($d->detail->description); ?></td>
                                        <td>
                                            <?php if($d->position=="Debit"): ?>
                                                <?php if($d->detail->amount < 0): ?>
                                                    -Rp<?php echo e(strrev(implode('.',str_split(strrev(strval(-1*$d->detail->amount)),3)))); ?>

                                                <?php else: ?>
                                                    Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($d->detail->amount)),3)))); ?>

                                                <?php endif; ?>
                                                <?php
                                                    $debit += $d->detail->amount;
                                                ?>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($d->position == "Kredit"): ?>
                                                <?php if($d->detail->amount < 0): ?>
                                                    -Rp<?php echo e(strrev(implode('.',str_split(strrev(strval(-1*$d->detail->amount)),3)))); ?>

                                                <?php else: ?>
                                                    Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($d->detail->amount)),3)))); ?>

                                                <?php endif; ?>
                                                <?php
                                                    $kredit += $d->detail->amount;
                                                ?>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($log['position'] == "Debit"): ?>
                                                <?php if($d->position == "Kredit"): ?>
                                                    <?php
                                                        $saldo_akhir -= $d->detail->amount;        
                                                    ?>
                                                <?php elseif($d->position == "Debit"): ?>
                                                    <?php
                                                        $saldo_akhir += $d->detail->amount;        
                                                    ?>
                                                <?php endif; ?>
                                            <?php elseif($log['position'] == "Kredit"): ?>
                                                <?php if($d->position == "Kredit"): ?>
                                                    <?php
                                                        $saldo_akhir += $d->detail->amount;        
                                                    ?>
                                                <?php elseif($d->position == "Debit"): ?>
                                                    <?php
                                                        $saldo_akhir -= $d->detail->amount;
                                                    ?>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php if($saldo_akhir < 0): ?>
                                                -Rp<?php echo e(strrev(implode('.',str_split(strrev(strval(-1*$saldo_akhir)),3)))); ?>

                                            <?php else: ?>
                                                Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($saldo_akhir)),3)))); ?>

                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- end content-->
                </div>
                <!--  end card  -->
            </div>
            <!-- end col-md-12 -->
        </div>
        <!-- end row -->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    $(document).ready(function () {
        $('#generalLedger').DataTable({
            "paging": false,
            "ordering": false,
            responsive: true,
            language: {
                search: "_INPUT_",
                searchPlaceholder: "Cari",
            }
        });
        var table = $('#generalLedger').DataTable();
        var test = table.row( ':last-child' ).data();
        $('#saldo_akhir').text(test[4]);
    });

    $(document).on('click', '#search', function(e){
        e.preventDefault();
        var year = $("select.groupbyYear").val();
        var akun = $("select.groupbyAccount").val();

        var url = "<?php echo e(route('buku_besar.index')); ?>?year=" + year + "&akun=" +akun;
        window.location.href = url;

    })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user/layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UI-TA\resources\views/user/bukuBesar.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Laporan Laba Rugi'); ?>

<?php $__env->startSection('title-page', 'Laporan Laba Rugi'); ?>

<?php $__env->startSection('content'); ?>
    <?php
    if (isset($_GET['year'])) {
        $dt = $_GET['year'];
    } else {
        $dt = date('Y');
    }

    ?>
    
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="header text-center mt-2 mb-2">
                        <h3 class="title" style="font-weight: 400;">Laba Rugi</h3>
                        <p class=""><strong>Periode</strong> <?php echo e($dt); ?></p>
                    </div>
                    <div class="card-body">
                        <div class="toolbar">
                            <div class="d-flex justify-content-between">
                                <div class="col-md-2 pl-0">
                                    <div class="form-group">
                                        <strong class="mr-3">Tahun : </strong>
                                        <select class="pl-1 padding-select groupbyYear" style="border-radius: 3px;"
                                            id="search">
                                            <option value="0" disabled="true" selected="true">Year</option>
                                            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($y->year); ?>" <?php echo e($year == $y->year ? 'selected' : ''); ?>>
                                                <?php echo e($y->year); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <b class="caret"></b>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="material-datatables mt-4">
                            <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                                <thead>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td style="width:60%">
                                            Pendapatan
                                        </td>
                                        <td style="width:15%"></td>
                                        <td style="width:15%"></td>
                                        <td style="width:10%"></td>
                                    </tr>
                                    <?php for($i = 0; $i < sizeof($incomeArray); $i++): ?>
                                        <tr>
                                            <td style="width:60%;padding-left: 1.5rem!important;">
                                                <strong><?php echo e($incomeArray[$i]['classification']); ?></strong>
                                            </td>
                                            <td style="width:15%"></td>
                                            <td style="width:15%"></td>
                                            <td style="width:10%"></td>
                                        </tr>
                                        <?php if(isset($incomeArray[$i]['name'])): ?>
                                            <?php for($y = 0; $y < sizeof($incomeArray[$i]['name']); $y++): ?> 
                                                <?php if($incomeArray[$i]['ending balance'][$y] !="0" ): ?>
                                                    <tr>
                                                        <td style="width:60%;padding-left: 3rem!important;">
                                                            <?php echo e($incomeArray[$i]['code'][$y]); ?>- <?php echo e($incomeArray[$i]['name'][$y]); ?>

                                                        </td>
                                                        <td style="width:15%">
                                                        </td>
                                                        <td style="width:10%">
                                                        </td>
                                                        <td class="text-right" style="width:10%">
                                                            <?php if($incomeArray[$i]['ending balance'][$y] < 0): ?>
                                                                -Rp<?php echo e(strrev(implode('.',str_split(strrev(strval(-1*$incomeArray[$i]['ending balance'][$y])),3)))); ?>

                                                            <?php else: ?>
                                                                Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($incomeArray[$i]['ending balance'][$y])),3)))); ?>

                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endfor; ?>
                                        <?php endif; ?>
                                        <tr>
                                            <td style="width:60%;padding-left: 1.5rem!important;">
                                                Total <?php echo e($incomeArray[$i]['classification']); ?>

                                            </td>
                                            <td style="width:15%"></td>
                                            <td style="width:15%"></td>
                                            <td class="text-right" style="width:10%"></td>
                                        </tr>
                                    <?php endfor; ?>
                                    <tr>
                                        <td style="width:60%">
                                            <strong>Total Pendapatan</strong>
                                        </td>
                                        <td style="width:15%"></td>
                                        <td style="width:15%"></td>
                                        <td class="text-right" style="width:10%">
                                            Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($income)),3)))); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">
                                            Biaya
                                        </td>
                                        <td style="width:15%"></td>
                                        <td style="width:15%"></td>
                                        <td style="width:10%"></td>
                                    </tr>
                                    <?php for($i = 0; $i < sizeof($expenseArray); $i++): ?>
                                        <tr>
                                            <td style="width:60%;padding-left: 1.5rem!important;">
                                                <strong><?php echo e($expenseArray[$i]['classification']); ?></strong>
                                            </td>
                                            <td style="width:15%"></td>
                                            <td style="width:15%"></td>
                                            <td style="width:10%"></td>
                                        </tr>
                                        <?php if(isset($incomeArray[$i]['name'])): ?>
                                            <?php for($j = 0; $j < sizeof($expenseArray[$i]['ending balance']); $j++): ?>
                                                <?php if($expenseArray[$i]['ending balance'][$j] !=0): ?>
                                                    <tr>
                                                        <td style="width:60%;padding-left: 3rem!important;">
                                                            <?php echo e($expenseArray[$i]['code'][$j]); ?> -
                                                            <?php echo e($expenseArray[$i]['name'][$j]); ?>

                                                        </td>
                                                        <td style="width:15%"></td>
                                                        <td style="width:15%"></td>
                                                        <td class="text-right" style="width:10%">
                                                            Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($expenseArray[$i]['ending balance'][$j])),3)))); ?>

                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endfor; ?>
                                        <?php endif; ?>
                                        <tr>
                                            <td style="width:60%;padding-left: 1.5rem!important;">
                                                Total <?php echo e($expenseArray[$i]['classification']); ?>

                                            </td>
                                            <td style="width:15%"></td>
                                            <td style="width:15%"></td>
                                            <td style="width:10%" class="text-right"></td>
                                        </tr>
                                    <?php endfor; ?>
                                    <tr>
                                        <td style="width:60%">
                                            <strong>Total Biaya</strong>
                                        </td>
                                        <td style="width:15%"></td>
                                        <td style="width:15%"></td>
                                        <td class="text-right" style="width:10%">
                                            <?php if($expense < 0): ?>
                                                <strong>-Rp<?php echo e(strrev(implode('.',str_split(strrev(strval(-1*$expense)),3)))); ?></strong>
                                            <?php else: ?>
                                                <strong>Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($expense)),3)))); ?></strong>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">
                                            <strong class="text-danger">Laba Usaha</strong>
                                        </td>
                                        <td style="width:15%"></td>
                                        <td style="width:15%"></td>
                                        <td class="text-right" style="width:10%">
                                            <strong class="text-danger">
                                                <?php if(($income - $expense) < 0): ?>
                                                    -Rp<?php echo e(strrev(implode('.',str_split(strrev(strval(-1*($income - $expense))),3)))); ?>

                                                <?php else: ?>
                                                    Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($income - $expense)),3)))); ?>

                                                <?php endif; ?>
                                            </strong>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">
                                            Pendapatan dan Biaya Lainnya
                                        </td>
                                        <td style="width:15%"></td>
                                        <td style="width:15%"></td>
                                        <td style="width:10%"></td>
                                    </tr>
                                    <?php for($i = 0; $i < sizeof($othersIncomeArray); $i++): ?>
                                        <tr>
                                            <td style="width:60%;padding-left: 1.5rem!important;">
                                                <strong><?php echo e($othersIncomeArray[$i]['classification']); ?></strong>
                                            </td>
                                            <td style="width:15%"></td>
                                            <td style="width:15%"></td>
                                            <td class="text-right" style="width:10%">
                                                <?php echo e($othersIncome); ?>

                                            </td>
                                        </tr>
                                    <?php endfor; ?>
                                    <?php for($i = 0; $i < sizeof($othersExpenseArray); $i++): ?>
                                        <tr>
                                            <td style="width:60%;padding-left: 1.5rem!important;">
                                                <strong><?php echo e($othersExpenseArray[$i]['classification']); ?></strong>
                                            </td>
                                            <td style="width:15%"></td>
                                            <td style="width:15%"></td>
                                            <td class="text-right" style="width:10%">
                                                <?php echo e($othersExpense); ?>

                                            </td>
                                        </tr>
                                    <?php endfor; ?>
                                    <tr>
                                        <td style="width:60%">
                                            <strong>Total Pendapatan dan Biaya Lainnya</strong>
                                        </td>
                                        <td style="width:15%"></td>
                                        <td style="width:15%"></td>
                                        <td class="text-right" style="width:10%"><?php echo e($othersIncome - $othersExpense); ?></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">
                                            <strong>SALDO LABA/RUGI TAHUN BERJALAN</strong>
                                        </td>
                                        <td style="width:15%"></td>
                                        <td style="width:15%"></td>
                                        <td class="text-right" style="width:10%">
                                            <?php if(($income + $othersIncome - $expense - $othersExpense) < 0): ?>
                                                -Rp<?php echo e(strrev(implode('.',str_split(strrev(strval(-1*($income + $othersIncome - $expense - $othersExpense))),3)))); ?>

                                            <?php else: ?>
                                                Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($income + $othersIncome - $expense - $othersExpense)),3)))); ?>

                                            <?php endif; ?> 
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                         </div>
                    </div>
                    <!-- end content-->
                </div>
                <!--  end card  -->
            </div>
            <!-- end col-md-12 -->
        </div>
        <!-- end row -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
    $(document).ready(function () {
        $('#datatables').DataTable({
            "paging": false,
            "ordering": false,
            "info": false,
            responsive: true,
            language: {
                search: "_INPUT_",
                searchPlaceholder: "Cari",
            }
        });
    });
    $(document).on('change', '#search', function (e) {
        e.preventDefault();
        var year = $("select.groupbyYear").val();

        var url = "/laporan_laba_rugi?year=" + year;
        window.location.href = url;

    })
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('user/layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UI-TA\resources\views/user/laporanLabaRugi.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('title-page', 'Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <?php if(auth()->check() && auth()->user()->hasRole('company')): ?>
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title">Edit Profile</h4>
                
            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('profile.update')); ?>">
                    <?php echo e(method_field('PUT')); ?>

                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="bmd-label-floating">Perusahaan</label>
                                <input type="text" class="form-control" value="<?php echo e($data->name); ?>" name="name">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="bmd-label-floating">Email</label>
                                <input type="email" class="form-control" value="<?php echo e($data->user->email); ?>" disabled>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="bmd-label-floating">No telp</label>
                                <input type="number" class="form-control" value="<?php echo e($data->phone_number); ?>"
                                    name="phone_number">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="bmd-label-floating">Alamat</label>
                                <input type="text" class="form-control" value="<?php echo e($data->address); ?>" name="address">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="bmd-label-floating">Status</label>
                                <input type="text" class="form-control" <?php if($data->is_actived == 0): ?>
                                value="Reguler"
                                <?php else: ?>
                                value="PRO"
                                <?php endif; ?>
                                disabled>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary pull-right">SIMPAN PROFILE</button>
                    <div class="clearfix"></div>
                </form>
            </div>
        </div>
        <?php endif; ?>
        <?php if(auth()->check() && auth()->user()->hasRole('employee')): ?>
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title">Edit Profile</h4>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('profile_karyawan.update')); ?>" method="post">
                    <?php echo e(method_field('PUT')); ?>

                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="bmd-label-floating">Company (disabled)</label>
                                <input type="text" class="form-control" disabled value="<?php echo e($data->company->name); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="bmd-label-floating">Nama Lengkap</label>
                                <input type="text" class="form-control" value="<?php echo e($data->name); ?>" name="name">
                                <input type="hidden" class="form-control" value="<?php echo e($data->id); ?>" name="id">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="bmd-label-floating">Email</label>
                                <input type="text" class="form-control" value="<?php echo e($data->user->email); ?>" disabled>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="bmd-label-floating">Bisnis</label>
                                <input type="text" class="form-control" disabled
                                    value="<?php echo e($data->business->business_name); ?>">
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary pull-right">Update Profile</button>
                    <div class="clearfix"></div>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('user/layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UI-TA\resources\views/user/profile.blade.php ENDPATH**/ ?>
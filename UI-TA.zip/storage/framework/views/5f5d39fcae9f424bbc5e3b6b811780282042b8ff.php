<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card">
                <div class="text-center mt-3 mb-1">
                    <h3> SIK <strong> BUMDES </strong> </h3>
                </div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('bisnis.store')); ?>">
                        <h3 class="font-weight-bold">Informasi Bisnis</h3>
                        <?php echo csrf_field(); ?>
                        <p class="mb-0">Nama Bisnis</p>
                        <div class="input-group">
                            <input class="form-control" name="business_name" type="text" 
                                required="true" aria-required="true" />
                        </div>
                        <?php if($errors->has('business_name')): ?>
                            <span class="invalid">
                                <strong><?php echo e($errors->first('business_name')); ?></strong>
                            </span>
                        <?php endif; ?>
                        <div class="row  mt-3">
                            <div class="col-12 d-flex justify-content-center">
                                <button type="submit" class="btn btn-register mb-3">Tambah Bisnis</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UI-TA\resources\views/auth/tambahBisnis.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-sm-6 col-lg-4">
            <div class="card">
                <div class="text-center mt-3 mb-1">
                    <h3> SIK <strong> BUMDES </strong> </h3>
                </div>

                <div class="card-body">
                    <form action="<?php echo e(route('login')); ?>" method="POST">
                        <h4 class="font-weight-bold">Masuk</h2>
                        <?php echo csrf_field(); ?>
                        <p class="mb-0">Email</p>
                        <div class="input-group mb-3">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <i class="material-icons" style="font-size:18px">
                                        email
                                    </i>
                                </div>
                            </div>
                            <input id="email" type="email" placeholder="Email "
                                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                                value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong>Email atau password salah</strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <p class="mb-0">Kata Sandi</p>
                        <div class="input-group mb-0">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <i class="material-icons" style="font-size:18px">
                                        lock
                                    </i>
                                </div>
                            </div>
                            <input id="password" placeholder="Password" type="password"
                                class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required
                                autocomplete="current-password">

                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="input-group mb-3">
                            
                            <div class="col-12 d-flex justify-content-end p-0">
                                <?php if(Route::has('password.request')): ?>
                                <a class="btn btn-link text-dark" href="<?php echo e(route('password.request')); ?>">
                                    <?php echo e(__('Lupa Kata Sandi?')); ?>

                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 d-flex justify-content-center">
                                <button type="submit" class="btn btn-register mb-3">MASUK</button>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 text-center">
                                <a href="<?php echo e(route('register')); ?>"
                                    class="text-center btn btn-make-user">Belum Punya Akun? <strong>Daftar!</strong></a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UI-TA\resources\views/auth/login.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Akun'); ?>

<?php $__env->startSection('title-page', 'Akun'); ?>

<?php $__env->startSection('content'); ?>
<div class="card p-4">
    <div class="row pt-3 pb-3 mr-1 d-flex justify-content-end">
        <div class="col-2 p-0">
            <a class="btn btn-primary dropdown-toggle float-right mb-2" href="#" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                Tambah
            </a>
            <div class="dropdown-menu">
                <a class="dropdown-item" data-toggle="modal" data-target="#klasifikasiModal">Tambah Klasifikasi</a>
                <a class="dropdown-item" data-toggle="modal" data-target="#akunModal">Tambah Akun</a>
            </div>
        </div>
    </div>
    <?php $__currentLoopData = $account_parent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card-header card-header-warning m-1 p-2 d-flex justify-content-between" data-toggle="collapse" href="#collapse<?php echo e($p->id); ?>" role="button"
            aria-expanded="false" aria-controls="collapse<?php echo e($p->id); ?>">
            <h4 class="card-title mb-0"><?php echo e($p->parent_name); ?></h4>
            <i class="material-icons">keyboard_arrow_down</i>
            
        </div>
    
        <div class="card-body collapse pt-0 pb-0 mb-0" id="collapse<?php echo e($p->id); ?>">
            <?php $__currentLoopData = $p->classification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <table class="table table-striped table-no-bordered table-hover mb-0" cellspacing="0" width="100%">
                    <tr>
                        <th class="p-2 text-center" style="width:8%"><strong><?php echo e($c->classification_code); ?></strong></th>
                        <th class="p-2"><strong><?php echo e($c->classification_name); ?></strong></th>
                        <th></th>
                        <td style="width:10%" class="text-center">
                            <button class="btnEditClassification btn-icon" type="button" rel="tooltip" title="Edit Akun" data-toggle="modal" data-target="#editKlasifikasiModal"
                                value="<?php echo e($c->id); ?>" data-parent= "<?php echo e($c->id_parent); ?>">
                                <i class="material-icons" style="color: #9c27b0;font-size:1.1rem;cursor: pointer;">edit</i>
                            </button>
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                            <button type="button" rel="tooltip" title="Remove" class="btn-icon remove_classification" id="<?php echo e($c->id); ?>">
                                <i class="material-icons" style="color:#f44336;font-size:1.1rem;cursor: pointer;">close</i>
                            </button>
                        </th>
                    </tr>    
                    <tbody>
                        <?php $__currentLoopData = $c->account; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center" style="width:5%" class="p-2"><?php echo e($account->account_code); ?></td>
                                <td style="width:60%" class="p-2"><?php echo e($account->account_name); ?></td>
                                <td><?php echo e($account->position); ?></td>
                                <td style="width:10%" class="text-center">
                                    <button class="btnEditAccount btn-icon" type="button" rel="tooltip" title="Edit Akun" data-toggle="modal" data-target="#editAkunModal" value="<?php echo e($account->id); ?>" parent="<?php echo e($p->id); ?>" classification="<?php echo e($c->id); ?>">
                                        <i class="material-icons" style="color: #9c27b0;font-size:1.1rem;cursor: pointer;">edit</i>
                                    </button>
                                    <button type="button" class="btn-icon remove" id="<?php echo e($account->id); ?>">
                                            <i class="material-icons" style="color:#f44336;font-size:1.1rem;cursor: pointer;">close</i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<div class="modal fade" id="klasifikasiModal" tabindex="-1" role="">
    <div class="modal-dialog modal-login" role="document">
        <div class="modal-content">
            <div class="card card-signup card-plain">
                <div class="modal-header">
                    <div class="card-header card-header-primary text-center">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                            <i class="material-icons">clear</i></button>
                        <h4 class="card-title">Tambah Klasifikasi</h4>
                    </div>
                </div>
                <form class="form" action="<?php echo e(route('classification.store')); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal-body">
                        <div class="card-body">
                            <div class="form-group">
                                <h6 class="text-dark font-weight-bold m-0">Parent Account</h6>
                                <select class="form-control parent" name="input_parent" required>
                                    <option value="" selected="true">Pilih Parent</option>
                                    <?php $__currentLoopData = $account_parent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option id="parentAkun" value="<?php echo e($a->id); ?>">
                                            <?php echo e($a->parent_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <h6 class="text-dark font-weight-bold m-0">Kode Klasifikasi Akun</h6>
                                <input type="text" class="form-control" aria-describedby="kodeKlasifikasiAkun"
                                    placeholder="ex. 11" name="input_code" value="<?php echo e(old('input_code')); ?>" required>
                                <?php $__errorArgs = ['input_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong>That code number has been taken. Please choose another.</strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <h6 class="text-dark font-weight-bold m-0">Nama Klasifikasi Akun</h6>
                                <input type="text" class="form-control" aria-describedby="namaKlasifikasiAkun"
                                    placeholder="ex. aset lancar" name="input_name" value="<?php echo e(old('input_name')); ?>" required>
                            </div>
                            <?php $__errorArgs = ['input_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-center">
                        <button type="submit" class="btn btn-primary btn-round">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="editKlasifikasiModal" tabindex="-1" role="">
    <div class="modal-dialog modal-login" role="document">
        <div class="modal-content">
            <div class="card card-signup card-plain">
                <div class="modal-header">
                    <div class="card-header card-header-primary text-center">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                            <i class="material-icons">clear</i></button>
                        <h4 class="card-title">Edit Klasifikasi</h4>
                    </div>
                </div>
                <form class="form" method="POST" action="" id="formClassification" enctype="multipart/form-data">
                    <?php echo e(method_field('PUT')); ?>

                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="card-body">
                            <input type="hidden" class="form-control" name="classification" id="id_classification">
                            <div class="form-group parentAccount_">
                                <h6 class="text-dark font-weight-bold m-0">Parent Account</h6>
                                <select class="form-control" name="edit_parent" id="parent" required>
                                    <option value="" selected="true" required>Pilih Parent</option>
                                    <?php $__currentLoopData = $account_parent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option id="parentAkun" name="parentAkun" value="<?php echo e($a->id); ?>">
                                            <?php echo e($a->parent_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group classificationCode">
                                <h6 class="text-dark font-weight-bold m-0">Kode Klasifikasi Akun</h6>
                                <input type="text" class="form-control" name="edit_code" aria-describedby="kodeKlasifikasiAkun"
                                    value="<?php echo e(old('edit_code')); ?>" required>
                                <?php $__errorArgs = ['edit_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert" id="hapus">
                                        <strong>That code number has been taken. Please choose another.</strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group classificationName">
                                <h6 class="text-dark font-weight-bold m-0">Nama Klasifikasi Akun</h6>
                                <input type="text" class="form-control" name="edit_name" aria-describedby="namaKlasifikasiAkun"
                                    value="<?php echo e(old('edit_name')); ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-center">
                        <button type="submit" class="btn btn-primary btn-round">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="akunModal" tabindex="-1" role="">
    <div class="modal-dialog modal-login" role="document">
        <div class="modal-content">
            <div class="card card-signup card-plain">
                <div class="modal-header">
                    <div class="card-header card-header-primary text-center">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                            <i class="material-icons">clear</i></button>
                        <h4 class="card-title">Tambah Akun</h4>
                    </div>
                </div>
                <form class="form" action="<?php echo e(route('akun.store')); ?>" method="POST">
                    <div class="modal-body">
                        <div class="card-body">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <h6 class="text-dark font-weight-bold m-0">Parent Akun</h6>
                                <select class="form-control changeParent_" name="input_parentAccount" required>
                                    <option selected="true" value="">Parent Akun</option>
                                    <?php $__currentLoopData = $account_parent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($a->id); ?>">
                                            <?php echo e($a->parent_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <h6 class="text-dark font-weight-bold m-0">Klasifikasi Akun</h6>
                                <select class="form-control classification_" name="input_classificationAccount" required>
                                    <option selected="true" value="">Klasifikasi Akun</option>
                                    <?php $__currentLoopData = $account_parent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $a->classification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($classification->id); ?>">
                                                <?php echo e($classification->classification_name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="row">
                                <div class="form-group col-6">
                                    <h6 class="text-dark font-weight-bold m-0">Kode Akun</h6>
                                    <input type="text" class="form-control" name="input_codeAccount" aria-describedby="kodeAkun"
                                        placeholder="ex. 1110" value="<?php echo e(old('input_codeAccount')); ?>" required>
                                        <?php $__errorArgs = ['input_codeAccount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong>That code number has been taken. Please choose another.</strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group col-6">
                                    <h6 class="text-dark font-weight-bold m-0">Posisi Normal</h6>
                                    <select class="form-control positionAccount" name="input_positionAccount" required>
                                        <option selected="true" value="">Posisi</option>
                                        <option value="Debit" <?php echo e(old('input_positionAccount')); ?> == Debit ? 'selected' : ''>Debit</option>
                                        <option value="Kredit" <?php echo e(old('input_positionAccount')); ?> == Kredit ? 'selected' : ''>Kredit</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <h6 class="text-dark font-weight-bold m-0">Nama Akun</h6>
                                <input type="text" class="form-control" name="input_nameAccount" aria-describedby="input_nameAccount"
                                    placeholder="ex. kas di bank" required value="<?php echo e(old('input_nameAccount')); ?>">
                            </div>

                        </div>
                    </div>
                    <div class="modal-footer justify-content-center">
                        <button type="submit" class="btn btn-primary btn-round">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="editAkunModal" tabindex="-1" role="">
    <div class="modal-dialog modal-login" role="document">
        <div class="modal-content">
            <div class="card card-signup card-plain">
                <div class="modal-header">
                    <div class="card-header card-header-primary text-center">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                            <i class="material-icons">clear</i></button>
                        <h4 class="card-title">Edit Akun</h4>
                    </div>
                </div>
                <form class="form" method="POST" action="" id="formAccount">
                    <?php echo e(method_field('PUT')); ?>

                    <?php echo csrf_field(); ?>
                    <input type="hidden" class="form-control" name="account" id="id_account">
                    <div class="modal-body">
                        <div class="card-body">

                            <div class="form-group parent">
                                <h6 class="text-dark font-weight-bold m-0">Parent Akun</h6>
                                <select class="form-control changeParent_" name="edit_parentAccount" required>
                                    <option value="" selected="true">Select Parent</option>
                                    <?php $__currentLoopData = $account_parent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($a->id); ?>">
                                            <?php echo e($a->parent_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group classification">
                                <h6 class="text-dark font-weight-bold m-0">Klasifikasi Akun</h6>
                                <select class="form-control classification_" name="edit_classificationAccount" required>
                                    <option value="" selected="true">Select Parent</option>
                                    <?php $__currentLoopData = $account_parent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $a->classification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($classification->id); ?>">
                                                <?php echo e($classification->classification_name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="row">
                                <div class="form-group col-6 acountCode">
                                    <h6 class="text-dark font-weight-bold m-0">Kode Akun</h6>
                                    <input type="text" class="form-control" name="edit_codeAccount" aria-describedby="kodeAkun"
                                        value="<?php echo e(old('edit_codeAccount')); ?>" required>
                                    <?php $__errorArgs = ['edit_codeAccount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong>That code number has been taken. Please choose another.</strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group col-6 position">
                                    <h6 class="text-dark font-weight-bold m-0">Posisi Normal</h6>
                                    <select class="form-control positionAccount" name="edit_positionAccount" required>
                                        <option disabled="true" selected="true">Posisi</option>
                                        <option value="Debit" <?php echo e(old('edit_positionAccount')); ?> == Debit ? 'selected' : ''>Debit</option>
                                        <option value="Kredit" <?php echo e(old('edit_positionAccount')); ?> == Kredit ? 'selected' : ''>Kredit</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group accountName">
                                <h6 class="text-dark font-weight-bold m-0">Nama Akun</h6>
                                <input type="text" class="form-control" name="edit_nameAccount" aria-describedby="namaAkun"
                                    value="<?php echo e(old('edit_nameAccount')); ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-center">
                        <button type="submit" class="btn btn-primary btn-round">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script type="text/javascript">
    $(document).ready(function () {
        <?php if($errors->has('input_code')): ?>
            var parent = "<?php echo e(old('input_parent')); ?>";
            $('.parent').val(parent);
            $('#klasifikasiModal').modal('show');
        <?php endif; ?>
        <?php if($errors->has('edit_code')): ?>
            $('#editKlasifikasiModal').modal('show');
            var parent = "<?php echo e(old('edit_parent')); ?>";
            $('#parent').val(parent);
            
            var id = "<?php echo e(old('classification')); ?>";
            var action = "<?php echo e(route('classification.index')); ?>/"+id;
            $('#formClassification').attr('action', action);
        <?php endif; ?>
        <?php if($errors->has('input_codeAccount')): ?>
            var id_parent = <?php echo e(old('input_parentAccount')); ?>;
            var id_classification = <?php echo e(old('input_classificationAccount')); ?>;
            var position = "<?php echo e(old('input_positionAccount')); ?>";
            $('select.changeParent_').val(id_parent);
            $('select.classification_').val(id_classification);
            $('select.positionAccount').val(position);
            $('#akunModal').modal('show');
        <?php endif; ?>
        <?php if($errors->has('edit_codeAccount')): ?>
            $('#editAkunModal').modal('show');
            var id_parent = <?php echo e(old('edit_parentAccount')); ?>;
            var id_classification = <?php echo e(old('edit_classificationAccount')); ?>;
            var position = "<?php echo e(old('edit_positionAccount')); ?>";
            var name = "<?php echo e(old('edit_nameAccount')); ?>";
            console.log(name);
            $('select.changeParent_').val(id_parent);
            $('select.classification_').val(id_classification);
            $('select.positionAccount').val(position);
            var id = "<?php echo e(old('account')); ?>";
            var action = "<?php echo e(route('akun.index')); ?>/"+id;
            $('#formAccount').attr('action', action);
        <?php endif; ?>

        $(document).on('click', '.btnEditClassification', function () {
            <?php if($errors->has('edit_code')): ?>            
                $('span.invalid-feedback').remove();
            <?php endif; ?>
            var id = $(this).attr('value');
            $('#id_classification').val(id);
            $.ajax({
                type        : 'get',
                url         : '<?php echo url('detailClassification'); ?>',
                data        : {'id':id},
                dataType    : 'html',
                success     : function(data){
                    var servers = $.parseJSON(data);

                    $.each(servers, function(index, value){
                        var numberCode = value.classification_code;
                        var nameCode = value.classification_name;
                        var id_parent = value.id_parent ;

                        $('div.classificationCode input').val(numberCode);
                        $('div.classificationName input').val(nameCode);
                        $("div.parentAccount_ select").val(id_parent);

                    });
                }
            });
            
            var action = "<?php echo e(route('classification.index')); ?>/"+id;
            $('#formClassification').attr('action',action);
        });

        $(document).on('click', '.btnEditAccount', function () {
            <?php if($errors->has('edit_codeAccount')): ?>            
                $('span.invalid-feedback').remove();
            <?php endif; ?>
            var id = $(this).attr('value');
            $('#id_account').val(id);
            var parent = $(this).attr('parent');
            var test = $(this).attr('classification');

            var div= $(".classification");
            var op=" ";

            $("div.parent select").val(parent);
            $.ajax({
                type        : 'GET',
                url         : '<?php echo url('detailAccount'); ?>',
                data        : {'id':id},
                dataType    : 'html',
                success     : function(data){
                    var servers = $.parseJSON(data);
                    $.each(servers, function(index, value){
                        var classification = value.id_classification;
                        var account_code = value.account_code;
                        var account_name = value.account_name;
                        var position = value.position;

                        $('div.classification select').val(classification);
                        $('div.acountCode input').val(account_code);
                        $("div.accountName input").val(account_name);
                        $("div.position select").val(position);
                    });
                }
            });

            $.ajax({
                type        : 'GET',
                url         : '<?php echo url('findClassification'); ?>',
                data        : {'id':parent},
                success:function(data){
                    op+='<option value="0" disabled="true"="true">Select Classification</option>';
                    for(var i=0;i<data.length;i++){
                    if (data[i].id == test) {
                        var x = "selected";
                    } else {
                        var x = "";
                    }
                    op+='<option '+x+' value="'+data[i].id+'">'+data[i].classification_name+'</option>'
                    }

                    $('div.classification select').html(" ");
                    $('div.classification select').append(op);
                }
            });

            var action = "<?php echo e(route('akun.index')); ?>/"+id;
            $('#formAccount').attr('action',action);
        });

        $(document).on('change', '.changeParent_', function(){
            var parent = $(this).val();
            console.log(parent);
            
            var div= $(this).parent().parent();
            var op=" ";
            
            $.ajax({
                type        : 'GET',
                url         : '<?php echo url('findClassification'); ?>',
                data        : {'id':parent},
                success:function(data){
                    op+='<option value="" selected="true">Select Classification</option>';
                    for(var i=0;i<data.length;i++){
                        op+='<option value="'+data[i].id+'">'+data[i].classification_name+'</option>'
                    }
                    div.find('.classification_').html(" ");
                    div.find('.classification_').append(op);
                }
            });

        });

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        // Delete a record
        $(document).on('click', '.remove', function(e) {
            e.preventDefault();
            var id = $(this).attr('id');
            
            // console.log(sid);
            var url = "<?php echo e(route('akun.index')); ?>/"+id;
            Swal.fire({
                title: 'Anda yakin ingin menghapus akun?',
                text: "Data akan dihapus secara permanen",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, hapus!',
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                cancelButtonText: 'Batal!'
            }).then((result) => {
                if (result.value) {
                    $.ajax({
                        type: "delete",
                        url: url,
                        dataType: "json",
                        success: (response) => {
                            Swal.fire(
                            'Dihapus!',
                            'Akun telah dihapus.',
                            'success'
                            )
                            $(this).closest('tr').remove();
                        }
                    });
                } else if (result.dismiss === Swal.DismissReason.cancel) {
                    Swal.fire(
                    'Batal',
                    'Akun batal dihapus :)',
                    'error'
                    )
                }
            })
        });

        // Delete a record
        $(document).on('click', '.remove_classification', function(e) {
            e.preventDefault();
            var id = $(this).attr('id');
            
            // console.log(sid);
            var url = "<?php echo e(route('classification.index')); ?>/"+id;
            Swal.fire({
                title: 'Anda yakin ingin menghapus klasifikasi?',
                text: "Data akan dihapus secara permanen",
                icon: 'warning',
                showCancelButton: true,
                cancelButtonText: 'Batal!',
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, hapus!',
            }).then((result) => {
                if (result.value) {
                    $.ajax({
                        type: "delete",
                        url: url,
                        dataType: "json",
                        success: (response) => {
                            Swal.fire(
                            'Dihapus!',
                            'Klasifikasi telah dihapus.',
                            'success'
                            )
                            $(this).closest('tr').remove();
                        }
                    });
                } else if (result.dismiss === Swal.DismissReason.cancel) {
                    Swal.fire(
                    'Batal',
                    'Data batal dihapus :)',
                    'error'
                    )
                }
            })
        });
    });
</script>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user/layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UI-TA\resources\views/user/akun.blade.php ENDPATH**/ ?>
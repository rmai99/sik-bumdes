<?php $__env->startSection('title', 'Neraca'); ?>

<?php $__env->startSection('title-page', 'Neraca'); ?>

<?php $__env->startSection('content'); ?>
<?php
    if (isset($_GET['year'])) {
        $dt = $_GET['year'];
    } else {
        $dt = date('Y');
    }
?>

<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="header text-center mt-2 mb-2">
                        <h3 class="title" style="font-weight: 400;">Neraca</h3>
                        <p><strong>Periode</strong> <?php echo e($dt); ?></p>
                    </div>
                    <div class="card-body">
                        <div class="toolbar">
                            <div class="d-flex justify-content-between">
                                <div class="col-md-2 pl-0">
                                    <div class="form-group">
                                        <strong class="mr-3">Tahun : </strong>
                                        <select class="pl-1 padding-select groupbyYear" id="search" style="border-radius: 3px;">
                                            <option value="0" disabled selected>Tahun</option>
                                            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <option value="<?php echo e($y->year); ?>" <?php echo e($year == $y->year ? 'selected' : ''); ?>>
                                                <?php echo e($y->year); ?>

                                              </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <b class="caret"></b>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="material-datatables mt-4">
                            <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                                <thead>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                      <td style="width:60%">Asset</td>
                                      <td style="width:15%"></td>
                                      <td style="width:15%"></td>
                                      <td style="width:10%"></td>
                                    </tr>
                                    <?php
                                      $sum = 0;
                                      $sum_biaya = 0;
                                      $sum_ekuitas = 0;
                                    ?>
                                    <?php for($i = 0; $i < sizeof($assetArray); $i++): ?>
                                      <tr>
                                          <td style="width:60%;padding-left: 1.5rem!important;">
                                            <strong><?php echo e($assetArray[$i]['classification']); ?></strong>
                                          </td>
                                          <td style="width:15%"></td>
                                          <td style="width:15%"></td>
                                          <td style="width:10%"></td>
                                      </tr>
                                        <?php if(isset($assetArray[$i]['name'])): ?>
                                          <?php for($y = 0; $y < sizeof($assetArray[$i]['name']); $y++): ?>
                                            <?php if($assetArray[$i]['ending balance'][$y] != "0"): ?>
                                            <tr>
                                                <td style="width:60%;padding-left: 3rem!important;">
                                                  <?php echo e($assetArray[$i]['code'][$y]); ?>- <?php echo e($assetArray[$i]['name'][$y]); ?>

                                                </td>
                                                <td style="width:15%">
                                                    
                                                </td>
                                                <td style="width:15%">
                                                </td>
                                                <td class="text-right" style="width:10%">
                                                  <?php if($assetArray[$i]['ending balance'][$y] < 0): ?>
                                                    - Rp<?php echo e(strrev(implode('.',str_split(strrev(strval(-1*$assetArray[$i]['ending balance'][$y])),3)))); ?>  
                                                  <?php else: ?>
                                                    Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($assetArray[$i]['ending balance'][$y])),3)))); ?>

                                                  <?php endif; ?>
                                                  <?php
                                                      $sum += $assetArray[$i]['ending balance'][$y];
                                                  ?>
                                                </td>
                                            </tr>
                                            <?php endif; ?>
                                          <?php endfor; ?>
                                        <?php endif; ?>
                                        <tr>
                                          <td style="width:60%;padding-left: 1.5rem!important;">
                                              <b>Total <?php echo e($assetArray[$i]['classification']); ?></b>
                                          </td>
                                          <td style="width:15%"></td>
                                          <td style="width:15%"></td>
                                          <td class="text-right" style="width:10%">
                                            <b>
                                              
                                              <?php if($assetArray[$i]['sum'] < 0): ?>
                                                - Rp<?php echo e(strrev(implode('.',str_split(strrev(strval(-1*$assetArray[$i]['sum'])),3)))); ?>  
                                              <?php else: ?>
                                                Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($assetArray[$i]['sum'])),3)))); ?>

                                              <?php endif; ?>
                                            </b>
                                          </td>
                                        </tr>
                                    <?php endfor; ?>
                                    <tr>
                                      <td style="width:60%">
                                          <strong>Total Asset</strong>
                                      </td>
                                      <td style="width:15%"></td>
                                      <td style="width:15%"></td>
                                      <td class="text-right" style="width:10%">
                                        <strong>
                                          <?php if($sum < 0): ?>
                                          - Rp<?php echo e(strrev(implode('.',str_split(strrev(strval(-1*$sum)),3)))); ?>

                                          <?php else: ?>
                                            Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($sum)),3)))); ?>

                                          <?php endif; ?>
                                        </strong>
                                      </td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">
                                            Liabilitas
                                        </td>
                                        <td style="width:15%"></td>
                                        <td style="width:15%"></td>
                                        <td style="width:10%"></td>
                                    </tr>
                                    <?php for($i = 0; $i < sizeof($liabilityArray); $i++): ?>
                                      <tr>
                                        <td style="width:60%;padding-left: 1.5rem!important;">
                                          <strong><?php echo e($liabilityArray[$i]['classification']); ?></strong>
                                        </td>
                                        <td style="width:15%"></td>
                                        <td style="width:15%"></td>
                                        <td style="width:10%"></td>
                                      </tr>
                                      <?php if(isset($assetArray[$i]['name'])): ?>
                                        <?php for($j = 0; $j < sizeof($liabilityArray[$i]['ending balance']); $j++): ?>
                                        <?php if($liabilityArray[$i]['ending balance'][$j] != 0): ?>
                                          <tr>
                                            <td style="width:60%;padding-left: 3rem!important;">
                                              <?php echo e($liabilityArray[$i]['code'][$j]); ?> - <?php echo e($liabilityArray[$i]['name'][$j]); ?>

                                            </td>
                                            <td style="width:15%">
                                                
                                            </td>
                                            <td style="width:15%">
                                            </td>
                                            <td class="text-right" style="width:10%">
                                              <?php if($liabilityArray[$i]['ending balance'][$j] < 0): ?>
                                                - Rp<?php echo e(strrev(implode('.',str_split(strrev(strval(-1*$liabilityArray[$i]['ending balance'][$j])),3)))); ?>

                                              <?php else: ?>
                                                Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($liabilityArray[$i]['ending balance'][$j])),3)))); ?>  
                                              <?php endif; ?>
                                              <?php
                                                  $sum_biaya += $liabilityArray[$i]['ending balance'][$j];
                                              ?>
                                            </td>
                                          </tr>
                                        <?php endif; ?>
                                        <?php endfor; ?>
                                      <?php endif; ?>
                                      <tr>
                                        <td style="width:60%;padding-left: 1.5rem!important;">
                                          <b>Total <?php echo e($liabilityArray[$i]['classification']); ?></b>
                                        </td>
                                        <td style="width:15%"></td>
                                        <td style="width:15%"></td>
                                        <td style="width:10%" class="text-right">
                                          </b>
                                            <?php if($liabilityArray[$i]['sum'] < 0): ?>
                                              - Rp<?php echo e(strrev(implode('.',str_split(strrev(strval(-1*$liabilityArray[$i]['sum'])),3)))); ?>

                                            <?php else: ?>
                                              Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($liabilityArray[$i]['sum'])),3)))); ?>  
                                            <?php endif; ?>
                                          </b>
                                        </td>
                                      </tr>
                                    <?php endfor; ?>
                                    <tr>
                                      <td style="width:60%">
                                          <strong>Total Liabilitas</strong>
                                      </td>
                                      <td style="width:15%"></td>
                                      <td style="width:15%"></td>
                                      <td class="text-right" style="width:10%">
                                        <strong>
                                          <?php if($sum_biaya < 0): ?>
                                            - Rp<?php echo e(strrev(implode('.',str_split(strrev(strval(-1*$sum_biaya)),3)))); ?>

                                          <?php else: ?>
                                            Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($sum_biaya)),3)))); ?>

                                          <?php endif; ?>
                                        </strong>
                                      </td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">
                                            Ekuitas
                                        </td>
                                        <td style="width:15%"></td>
                                        <td style="width:15%"></td>
                                        <td style="width:10%"></td>
                                    </tr>
                                    <?php for($i = 0; $i < sizeof($equityArray); $i++): ?>
                                      <tr>
                                        <td style="width:60%;padding-left: 1.5rem!important;">
                                          <strong><?php echo e($equityArray[$i]['classification']); ?></strong>
                                        </td>
                                        <td style="width:15%"></td>
                                        <td style="width:15%"></td>
                                        <td style="width:10%"></td>
                                      </tr>
                                      <?php if(isset($assetArray[$i]['name'])): ?>
                                        <?php for($j = 0; $j < sizeof($equityArray[$i]['ending balance']); $j++): ?>
                                        <?php if($equityArray[$i]['name'][$j] != "Laba Ditahan"): ?>
                                          <tr>
                                            <td style="width:60%;padding-left: 3rem!important;">
                                              <?php echo e($equityArray[$i]['code'][$j]); ?> - <?php echo e($equityArray[$i]['name'][$j]); ?>

                                            </td>
                                            <td style="width:15%">
                                                
                                            </td>
                                            <td style="width:15%">
                                            </td>
                                            <td class="text-right" style="width:10%">
                                              <?php if($equityArray[$i]['ending balance'][$j] < 0): ?>
                                                - Rp<?php echo e(strrev(implode('.',str_split(strrev(strval(-1*$equityArray[$i]['ending balance'][$j])),3)))); ?>

                                              <?php else: ?>
                                                Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($equityArray[$i]['ending balance'][$j])),3)))); ?>

                                              <?php endif; ?>
                                              <?php
                                                  $sum_ekuitas += $equityArray[$i]['ending balance'][$j];
                                              ?>
                                            </td>
                                          </tr>
                                        <?php endif; ?>
                                        <?php if($equityArray[$i]['name'][$j] == "Laba Ditahan"): ?>
                                          <tr>
                                            <td style="width:60%;padding-left: 3rem!important;">
                                              <?php echo e($equityArray[$i]['code'][$j]); ?> - <?php echo e($equityArray[$i]['name'][$j]); ?>

                                            </td>
                                            <td style="width:15%">
                                                
                                            </td>
                                            <td style="width:15%">
                                            </td>
                                            <td class="text-right" style="width:10%">
                                              <?php if($equitas < 0): ?>
                                                - Rp<?php echo e(strrev(implode('.',str_split(strrev(strval(-1*$equitas)),3)))); ?>

                                              <?php else: ?>
                                                Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($equitas)),3)))); ?>

                                              <?php endif; ?>
                                              <?php
                                                  $sum_ekuitas += $equitas;
                                              ?>
                                            </td>
                                          </tr>
                                        <?php endif; ?>
                                        <?php endfor; ?>
                                      <?php endif; ?>
                                      <tr>
                                        <td style="width:60%;padding-left: 1.5rem!important;">
                                          Total <?php echo e($equityArray[$i]['classification']); ?>

                                        </td>
                                        <td style="width:15%"></td>
                                        <td style="width:15%"></td>
                                        <td style="width:10%" class="text-right"></td>
                                      </tr>
                                    <?php endfor; ?>
                                    <tr>
                                      <td style="width:60%">
                                          <strong>Total Ekuitas</strong>
                                      </td>
                                      <td style="width:15%"></td>
                                      <td style="width:15%"></td>
                                      <td class="text-right" style="width:10%">
                                        <strong>
                                          <?php if($sum_ekuitas < 0): ?>  
                                            - Rp<?php echo e(strrev(implode('.',str_split(strrev(strval(-1*$sum_ekuitas)),3)))); ?></strong>
                                          <?php else: ?>
                                            Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($sum_ekuitas)),3)))); ?></strong>
                                          <?php endif; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td style="width:60%">
                                          <strong>Total Liabilitas dan Ekuitas</strong>
                                      </td>
                                      <td style="width:15%"></td>
                                      <td style="width:15%"></td>
                                      <td class="text-right" style="width:10%">
                                        <strong>
                                          <?php if($sum_ekuitas+$sum_biaya < 0): ?>  
                                            - Rp<?php echo e(strrev(implode('.',str_split(strrev(strval(-1*($sum_ekuitas+$sum_biaya))),3)))); ?></strong>
                                          <?php else: ?>
                                            Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($sum_ekuitas+$sum_biaya)),3)))); ?></strong>
                                          <?php endif; ?>
                                        </strong>
                                      </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="row">
                              <div class="col-lg-6 text-center">
                                Total Aset
                                <br>
                                <strong>
                                  <?php if($sum < 0): ?>
                                  - Rp<?php echo e(strrev(implode('.',str_split(strrev(strval(-1*$sum)),3)))); ?>

                                  <?php else: ?>
                                    Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($sum)),3)))); ?>

                                  <?php endif; ?>
                                </strong>
                              </div>
                              <div class="col-lg-6 text-center">
                                Total Liabilitas dan Ekuitas
                                <br>
                                <strong>
                                  <?php if($sum_ekuitas+$sum_biaya < 0): ?>  
                                    - Rp<?php echo e(strrev(implode('.',str_split(strrev(strval(-1*($sum_ekuitas+$sum_biaya))),3)))); ?></strong>
                                  <?php else: ?>
                                    Rp<?php echo e(strrev(implode('.',str_split(strrev(strval($sum_ekuitas+$sum_biaya)),3)))); ?></strong>
                                  <?php endif; ?>
                                </strong>
                              </div>
                            </div>
                        </div>
                    </div>
                    <!-- end content-->
                </div>
                <!--  end card  -->
            </div>
            <!-- end col-md-12 -->
        </div>
        <!-- end row -->
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
    $(document).ready(function () {
        $('#datatables').DataTable({
            "paging":   false,
            "ordering": false,
            "info":     false,
            responsive: true,
            language: {
            search: "_INPUT_",
            searchPlaceholder: "Cari",
            }
        });
    });
    $(document).on('change', '#search', function(e){
        e.preventDefault();
        var year = $("select.groupbyYear").val();

        var url = "<?php echo e(route('neraca')); ?>?year=" + year;
        window.location.href = url;

    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user/layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UI-TA\resources\views/user/neraca.blade.php ENDPATH**/ ?>
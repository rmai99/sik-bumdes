<?php $__env->startSection('title', 'Karyawan'); ?>

<?php $__env->startSection('title-page', 'Karyawan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <form method="POST" action="<?php echo e(route('karyawan.store')); ?>" class="form-horizontal">
                <?php echo csrf_field(); ?>
                <div class="card ">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Tambah Karyawan</h4>
                        <p class="card-category"></p>
                    </div>
                    <div class="card-body ">
                        <div class="row">
                            <div class="col-md-12 text-right">
                                <a href="<?php echo e(route('karyawan.index')); ?>"
                                    class="btn btn-sm btn-primary">Daftar Karyawan</a>
                            </div>
                        </div>
                        <div class="row">
                            <label class="col-sm-2 col-form-label">Nama</label>
                            <div class="col-sm-7">
                                <div class="form-group">
                                    <input class="form-control" name="name" type="text"
                                        placeholder="Name" value="<?php echo e(old('name')); ?>" required="true" aria-required="true" />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <label class="col-sm-2 col-form-label">Email</label>
                            <div class="col-sm-7">
                                <div class="form-group">
                                    <input class="form-control" name="email" type="email"
                                        placeholder="Email" value="<?php echo e(old('email')); ?>" required />
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <label class="col-sm-2 col-form-label" for="input-password">Password</label>
                            <div class="col-sm-7">
                                <div class="form-group">
                                    <input class="form-control" name="password" id="input-password" type="password"
                                        placeholder="password" value="" required />
                                </div>
                                <?php if($errors->has('password')): ?>
                                    <span class="invalid">
                                        <?php echo e($errors->first('password')); ?>

                                    </span>
                                <?php endif; ?> 
                            </div>
                        </div>
                        <div class="row">
                            <label class="col-sm-2 col-form-label" for="input-password-confirmation">Akses Bisnis</label>
                            <div class="col-sm-7">
                                <div class="form-group">
                                    <select class="form-control" name="id_business" required>
                                        <option value="" selected>Bisnis</option>
                                        <?php $__currentLoopData = $business; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->business_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer ml-auto mr-auto">
                        <button type="submit" class="btn btn-primary">Tambah Karyawan</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user/layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UI-TA\resources\views/user/tambahKaryawan.blade.php ENDPATH**/ ?>